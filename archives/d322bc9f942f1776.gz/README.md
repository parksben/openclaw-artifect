# niuma-server

> 牛马（Niuma）多 Agent 协作平台 — 服务端

## 简介

niuma-server 是牛马 App 和桌面端的后端服务，负责：

- 用户认证（邮箱 OTP + JWT）
- 管理 Agent、项目、聊天、消息数据
- 对接 OpenClaw，将客户端请求路由到对应 Agent
- SSE 流式转发 Agent 响应给客户端

## 技术栈

| 技术 | 用途 |
|------|------|
| Node.js + Express | HTTP 服务 |
| SQLite（sqlite3） | 数据存储 |
| nodemailer | 邮箱 OTP 发送 |
| JWT | 会话认证 |
| SSE | 流式响应 |

## 快速部署

推荐通过 [niuma-cli](https://github.com/parksben/niuma-cli) 一键部署：

```bash
curl -fsSL https://raw.githubusercontent.com/parksben/niuma-cli/main/install.sh | bash
```

> 国内用户：
> ```bash
> curl -fsSL https://ghproxy.net/https://raw.githubusercontent.com/parksben/niuma-cli/main/install.sh | bash
> ```

## 环境变量

| 变量 | 说明 | 示例 |
|------|------|------|
| `PORT` | 服务端口（默认 3002） | `3002` |
| `JWT_SECRET` | JWT 签名密钥 | 随机字符串 |
| `SMTP_HOST` | SMTP 服务器地址 | `smtp.126.com` |
| `SMTP_PORT` | SMTP 端口 | `465` |
| `SMTP_USER` | 发件邮箱 | `xxx@126.com` |
| `SMTP_PASS` | SMTP 授权码 | |
| `OPENCLAW_PATH` | OpenClaw 安装路径 | `/root/.openclaw` |

## 相关仓库

- 发布入口：[niuma](https://github.com/parksben/niuma)
- CLI 工具：[niuma-cli](https://github.com/parksben/niuma-cli)
