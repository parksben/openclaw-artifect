require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { initSchema } = require('./src/db');
const { seed } = require('./src/seed');
const WorkspaceService = require('./src/services/WorkspaceService');

const app = express();
app.use(cors());
app.use(express.json());

// Routes
app.use('/auth', require('./src/routes/auth'));
app.use('/api/auth', require('./src/routes/auth'));
app.use('/agents', require('./src/routes/agents'));
app.use('/api/agents', require('./src/routes/agents'));  // App: GET/POST/DELETE /api/agents
app.use('/projects', require('./src/routes/projects'));
app.use('/api/projects', require('./src/routes/projects'));
app.use('/projects/:id/docs', require('./src/routes/docs'));
app.use('/api/projects/:id/docs', require('./src/routes/docs'));
app.use('/projects/:id/tasks', require('./src/routes/tasks'));
app.use('/api/projects/:id/tasks', require('./src/routes/tasks'));
app.use('/api/agents', require('./src/routes/agent-tasks'));  // agent task queries
app.use('/chats', require('./src/routes/chats'));
app.use('/api/chats', require('./src/routes/chats'));
app.use('/api/overview', require('./src/routes/overview'));
app.use('/api', require('./src/routes/uploads'));
app.use('/api/groups', require('./src/routes/groups'));
app.use('/api/connect', require('./src/routes/connect'));
app.use('/connect', require('./src/routes/connect'));
app.use('/api/templates', require('./src/routes/templates'));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Static file serving (niuma-web build output)
app.use(express.static(path.join(__dirname, 'public')));

// Health check
app.get('/health', (req, res) => {
  res.json({ ok: true, version: require('./package.json').version, ts: Date.now() });
});

// SPA fallback: non-/api, non-/ws routes return index.html
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api') && !req.path.startsWith('/ws')) {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  }
});

const PORT = process.env.PORT || 3002;

async function start() {
  await initSchema();
  await WorkspaceService.migrate();
  await seed();

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`[niuma-server] Listening on http://0.0.0.0:${PORT}`);
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error(`[niuma-server] Port ${PORT} already in use. Killing existing process...`);
      const { execSync } = require('child_process');
      try {
        // macOS / Linux: find and kill the process on this port
        const pid = execSync(
          `lsof -ti tcp:${PORT} 2>/dev/null || fuser ${PORT}/tcp 2>/dev/null || true`,
          { stdio: ['pipe', 'pipe', 'pipe'] }
        ).toString().trim();
        const pids = pid.split(/\s+/).filter(p => /^\d+$/.test(p) && Number(p) !== process.pid);
        for (const p of pids) {
          try { execSync(`kill -9 ${p}`); } catch (_) {}
        }
        console.log(`[niuma-server] Killed old process(es): ${pids.join(', ')}. Retrying...`);
      } catch (_) {}
      // Retry after short delay
      setTimeout(() => {
        server.listen(PORT, '0.0.0.0');
      }, 1500);
    } else {
      console.error('[niuma-server] Startup error:', err);
      process.exit(1);
    }
  });
}

start().catch(err => {
  console.error('[niuma-server] Startup error:', err);
  process.exit(1);
});
