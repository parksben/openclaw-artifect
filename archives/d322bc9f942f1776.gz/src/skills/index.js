// 导出所有内置模板
const templates = require('./templates.json');

module.exports = {
  templates,
  getTemplate: (id) => templates.find(t => t.id === id),
};
