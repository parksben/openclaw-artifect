/**
 * WorkspaceService.js
 * File-first storage for group workspaces.
 * Each group gets an isolated git repo under workspace/projects/{groupId}-{groupName}/
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { execSync, execFileSync } = require('child_process');
const { runAsync, getAsync } = require('../db');

const WORKSPACE_ROOT = process.env.WORKSPACE_ROOT || path.resolve('./workspace/projects');

/**
 * WorkspaceService — manage file-system workspaces for groups.
 */
class WorkspaceService {
  constructor() {
    if (!fs.existsSync(WORKSPACE_ROOT)) {
      fs.mkdirSync(WORKSPACE_ROOT, { recursive: true });
    }
  }

  // ──────────────────────────────────────────────────────────────
  // Workspace init
  // ──────────────────────────────────────────────────────────────

  /**
   * Initialize a workspace directory + git repo for a group.
   * Idempotent — safe to call multiple times.
   * @param {string} groupId
   * @param {string} groupName
   * @returns {string} workspace path
   */
  createGroupWorkspace(groupId, groupName) {
    const safeName = (groupName || groupId).replace(/[^\w\u4e00-\u9fa5-]/g, '_');
    const dirName = `${groupId}-${safeName}`;
    const workspacePath = path.join(WORKSPACE_ROOT, dirName);

    // Create subdirectories
    for (const sub of ['messages', 'docs', 'code', 'tasks', 'knowledge']) {
      fs.mkdirSync(path.join(workspacePath, sub), { recursive: true });
    }

    // Write .meta.json
    const metaPath = path.join(workspacePath, '.meta.json');
    if (!fs.existsSync(metaPath)) {
      fs.writeFileSync(metaPath, JSON.stringify({
        groupId,
        groupName,
        createdAt: new Date().toISOString(),
      }, null, 2));
    }

    // git init if not already
    const gitDir = path.join(workspacePath, '.git');
    if (!fs.existsSync(gitDir)) {
      execFileSync('git', ['-C', workspacePath, 'init'], { stdio: 'ignore' });
      execFileSync('git', ['-C', workspacePath, 'config', 'user.email', 'niuma-bot@localhost'], { stdio: 'ignore' });
      execFileSync('git', ['-C', workspacePath, 'config', 'user.name', 'NiumaBot'], { stdio: 'ignore' });
      // Initial commit
      execFileSync('git', ['-C', workspacePath, 'add', '.meta.json'], { stdio: 'ignore' });
      execFileSync('git', ['-C', workspacePath, 'commit', '-m', `init: workspace for ${groupId}`], { stdio: 'ignore' });
    }

    return workspacePath;
  }

  /**
   * Get workspace path for a group. Throws if not found.
   * @param {string} groupId
   * @returns {string}
   */
  getWorkspacePath(groupId) {
    // Find directory starting with groupId
    const entries = fs.readdirSync(WORKSPACE_ROOT);
    const dir = entries.find(e => e.startsWith(`${groupId}-`) || e === groupId);
    if (!dir) throw new Error(`WorkspaceService: workspace for group ${groupId} not found`);
    return path.join(WORKSPACE_ROOT, dir);
  }

  // ──────────────────────────────────────────────────────────────
  // Messages
  // ──────────────────────────────────────────────────────────────

  /**
   * Append a message to the JSONL log for today.
   * @param {string} groupId
   * @param {{ id: string, ts: number, from: string, content: string, [key: string]: any }} message
   */
  appendMessage(groupId, message) {
    const workspacePath = this.getWorkspacePath(groupId);
    const date = new Date(message.ts || Date.now()).toISOString().slice(0, 10);
    const logFile = path.join(workspacePath, 'messages', `${date}.jsonl`);
    const line = JSON.stringify(message) + '\n';
    fs.appendFileSync(logFile, line, 'utf8');
  }

  /**
   * Get the most recent N messages from JSONL logs.
   * Reads files in reverse date order.
   * @param {string} groupId
   * @param {number} [limit=50]
   * @returns {object[]}
   */
  getRecentMessages(groupId, limit = 50) {
    const workspacePath = this.getWorkspacePath(groupId);
    const messagesDir = path.join(workspacePath, 'messages');

    const files = fs.readdirSync(messagesDir)
      .filter(f => f.endsWith('.jsonl'))
      .sort()
      .reverse();

    const results = [];
    for (const file of files) {
      if (results.length >= limit) break;
      const lines = fs.readFileSync(path.join(messagesDir, file), 'utf8')
        .split('\n')
        .filter(Boolean)
        .reverse();
      for (const line of lines) {
        if (results.length >= limit) break;
        try { results.push(JSON.parse(line)); } catch { /* skip malformed */ }
      }
    }

    return results.reverse();
  }

  // ──────────────────────────────────────────────────────────────
  // Document & code writing
  // ──────────────────────────────────────────────────────────────

  /**
   * Write a Markdown document to docs/ and git commit.
   * @param {string} groupId
   * @param {string} filename - e.g. "README.md"
   * @param {string} content
   */
  writeDoc(groupId, filename, content) {
    const workspacePath = this.getWorkspacePath(groupId);
    const filePath = path.join(workspacePath, 'docs', filename);
    _ensureDir(path.dirname(filePath));
    fs.writeFileSync(filePath, content, 'utf8');
    this.gitCommit(groupId, `docs: update ${filename}`);
  }

  /**
   * Write a code file to code/ and git commit.
   * @param {string} groupId
   * @param {string} filePath - relative path under code/, e.g. "src/index.js"
   * @param {string} content
   */
  writeCode(groupId, filePath, content) {
    const workspacePath = this.getWorkspacePath(groupId);
    const absPath = path.join(workspacePath, 'code', filePath);
    _ensureDir(path.dirname(absPath));
    fs.writeFileSync(absPath, content, 'utf8');
    this.gitCommit(groupId, `code: update ${filePath}`);
  }

  // ──────────────────────────────────────────────────────────────
  // File listing & reading
  // ──────────────────────────────────────────────────────────────

  /**
   * List files in a subdirectory of the workspace.
   * @param {string} groupId
   * @param {string} [subdir=''] - relative subdir, e.g. 'docs'
   * @returns {string[]} relative file paths
   */
  listFiles(groupId, subdir = '') {
    const workspacePath = this.getWorkspacePath(groupId);
    const target = subdir ? path.join(workspacePath, subdir) : workspacePath;
    if (!fs.existsSync(target)) return [];
    return _walkDir(target).map(f => path.relative(workspacePath, f));
  }

  /**
   * Read a file from the workspace.
   * @param {string} groupId
   * @param {string} filePath - relative path within workspace
   * @returns {string} file content
   */
  readFile(groupId, filePath) {
    const workspacePath = this.getWorkspacePath(groupId);
    const absPath = path.join(workspacePath, filePath);
    if (!fs.existsSync(absPath)) throw new Error(`WorkspaceService: file not found: ${filePath}`);
    return fs.readFileSync(absPath, 'utf8');
  }

  // ──────────────────────────────────────────────────────────────
  // Git
  // ──────────────────────────────────────────────────────────────

  /**
   * Stage all changes and create a git commit.
   * @param {string} groupId
   * @param {string} message - commit message
   */
  gitCommit(groupId, message) {
    const workspacePath = this.getWorkspacePath(groupId);
    try {
      execFileSync('git', ['-C', workspacePath, 'add', '.'], { stdio: 'ignore' });
      execFileSync('git', ['-C', workspacePath, 'commit', '-m', message, '--allow-empty-message'], { stdio: 'ignore' });
    } catch (err) {
      // Ignore "nothing to commit" errors
      if (!err.message.includes('nothing to commit')) {
        throw new Error(`WorkspaceService.gitCommit failed: ${err.message}`);
      }
    }
  }

  // ──────────────────────────────────────────────────────────────
  // DB integration
  // ──────────────────────────────────────────────────────────────

  /**
   * Persist workspace_path to the groups DB record.
   * Requires workspace_path column to exist (migration below).
   * @param {string} groupId
   * @param {string} workspacePath
   * @param {string} [gitRemote]
   */
  async saveWorkspaceMeta(groupId, workspacePath, gitRemote = null) {
    await runAsync(
      'UPDATE chats SET workspace_path = ?, git_remote = ? WHERE id = ?',
      [workspacePath, gitRemote, groupId]
    );
  }

  /**
   * Run DB migrations to add workspace columns.
   * Idempotent — safe to call at startup.
   */
  static async migrate() {
    const { db } = require('../db');
    db.run(`ALTER TABLE chats ADD COLUMN workspace_path TEXT`, () => {});
    db.run(`ALTER TABLE chats ADD COLUMN git_remote TEXT`, () => {});
    db.run(`ALTER TABLE chats ADD COLUMN status TEXT DEFAULT 'running'`, () => {});
    db.run(`ALTER TABLE chats ADD COLUMN archived INTEGER DEFAULT 0`, () => {});
  }
}

// ──────────────────────────────────────────────────────────────
// Utility
// ──────────────────────────────────────────────────────────────

function _ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
}

function _walkDir(dir) {
  const results = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(..._walkDir(full));
    } else {
      results.push(full);
    }
  }
  return results;
}

module.exports = WorkspaceService;
