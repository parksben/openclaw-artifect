/**
 * LifecycleService.js
 * Controls project (group) lifecycle: pause, resume, stop.
 */

'use strict';

const { getAsync, allAsync, runAsync } = require('../db');
const { emit } = require('../events');
const { v4: uuidv4 } = require('uuid');

/**
 * LifecycleService — pause, resume, and stop group projects.
 */
class LifecycleService {
  /**
   * @param {import('./AgentService')} agentService
   */
  constructor(agentService) {
    this._agentService = agentService;
  }

  /**
   * Apply a lifecycle action to a group.
   * @param {string} groupId - chat ID
   * @param {'pause'|'resume'|'stop'} action
   * @returns {Promise<{ ok: boolean, message: string }>}
   */
  async control(groupId, action) {
    const group = await getAsync('SELECT * FROM chats WHERE id = ?', [groupId]);
    if (!group) throw new Error(`LifecycleService: group ${groupId} not found`);

    switch (action) {
      case 'pause':  return this._pause(group);
      case 'resume': return this._resume(group);
      case 'stop':   return this._stop(group);
      default:
        throw new Error(`LifecycleService: unknown action "${action}"`);
    }
  }

  // ──────────────────────────────────────────────────────────────
  // Actions
  // ──────────────────────────────────────────────────────────────

  /**
   * Pause the project.
   * 1. Set status = 'paused'
   * 2. Notify all employee sessions
   * 3. Save snapshot system message
   * @param {object} group
   * @private
   */
  async _pause(group) {
    await runAsync('UPDATE chats SET status = ? WHERE id = ?', ['paused', group.id]);

    const employees = await this._getEmployees(group.id);

    // Notify each session (best-effort, ignore errors)
    const pauseNotice = `项目「${group.title || group.id}」已暂停，请保存当前状态，等待恢复指令。`;
    await Promise.allSettled(
      employees.map(emp => emp.session_id
        ? this._agentService.sendMessage(emp.session_id, pauseNotice).catch(() => {})
        : Promise.resolve()
      )
    );

    // Build snapshot: last message from each employee
    const summaries = await Promise.all(
      employees.map(async emp => {
        const last = await getAsync(
          `SELECT content FROM messages
           WHERE chat_id = ? AND sender_type = 'agent' AND sender_id = ?
           ORDER BY created_at DESC LIMIT 1`,
          [group.id, emp.agent_id]
        );
        return `${emp.name}：${last ? last.content.slice(0, 100) : '（无记录）'}`;
      })
    );

    const snapshotContent = `【暂停快照】${new Date().toISOString()}\n${summaries.join('\n')}`;
    await this._saveSystemMessage(group.id, snapshotContent, 'pause_snapshot');

    emit(group.id, { type: 'system', event: 'paused', content: pauseNotice });
    return { ok: true, message: '项目已暂停' };
  }

  /**
   * Resume the project.
   * 1. Set status = 'running'
   * 2. Read last pause snapshot
   * 3. Notify PM employee
   * @param {object} group
   * @private
   */
  async _resume(group) {
    await runAsync('UPDATE chats SET status = ? WHERE id = ?', ['running', group.id]);

    // Read last pause snapshot
    const snapshot = await getAsync(
      `SELECT content FROM messages
       WHERE chat_id = ? AND type = 'pause_snapshot'
       ORDER BY created_at DESC LIMIT 1`,
      [group.id]
    );
    const snapshotText = snapshot ? snapshot.content : '（无暂停记录）';

    // Find PM employee (level = 'owner' or role_type like 'PM')
    const pm = await getAsync(
      `SELECT a.id as agent_id, a.name FROM chat_agents ca
       JOIN agents a ON ca.agent_id = a.id
       WHERE ca.chat_id = ?
       ORDER BY a.created_at ASC LIMIT 1`,
      [group.id]
    );

    if (pm) {
      const resumeMsg = `项目已恢复，上次暂停时状态：\n${snapshotText}\n\n请继续推进。`;
      // Get session for PM if available
      const session = await getAsync(
        `SELECT session_id FROM agent_sessions WHERE agent_id = ? AND chat_id = ?`,
        [pm.agent_id, group.id]
      ).catch(() => null);

      if (session && session.session_id) {
        await this._agentService.sendMessage(session.session_id, resumeMsg).catch(() => {});
      }
    }

    const resumeNotice = `项目「${group.title || group.id}」已恢复运行。`;
    await this._saveSystemMessage(group.id, resumeNotice, 'system');
    emit(group.id, { type: 'system', event: 'resumed', content: resumeNotice });
    return { ok: true, message: '项目已恢复' };
  }

  /**
   * Stop the project.
   * 1. Set status = 'stopped'
   * 2. Kill all employee sessions
   * 3. Save system message
   * 4. Mark group as archived (readonly)
   * @param {object} group
   * @private
   */
  async _stop(group) {
    await runAsync('UPDATE chats SET status = ? WHERE id = ?', ['stopped', group.id]);

    // Kill all sessions
    const sessions = await allAsync(
      `SELECT session_id FROM agent_sessions WHERE chat_id = ?`,
      [group.id]
    ).catch(() => []);

    await Promise.allSettled(
      sessions.map(s => this._agentService.killEmployee(s.session_id).catch(() => {}))
    );

    const stopMsg = `项目「${group.title || group.id}」已结束。群聊已归档（只读）。`;
    await this._saveSystemMessage(group.id, stopMsg, 'system');

    // Mark as archived
    await runAsync('UPDATE chats SET archived = 1 WHERE id = ?', [group.id]).catch(() => {});

    emit(group.id, { type: 'system', event: 'stopped', content: stopMsg });
    return { ok: true, message: '项目已结束' };
  }

  // ──────────────────────────────────────────────────────────────
  // Helpers
  // ──────────────────────────────────────────────────────────────

  /**
   * Get all employees in a group with their session IDs.
   * @param {string} groupId
   * @returns {Promise<Array>}
   * @private
   */
  async _getEmployees(groupId) {
    return allAsync(
      `SELECT ca.agent_id, a.name, s.session_id
       FROM chat_agents ca
       JOIN agents a ON ca.agent_id = a.id
       LEFT JOIN agent_sessions s ON s.agent_id = ca.agent_id AND s.chat_id = ca.chat_id
       WHERE ca.chat_id = ?`,
      [groupId]
    ).catch(() => allAsync(
      `SELECT ca.agent_id, a.name, NULL as session_id
       FROM chat_agents ca
       JOIN agents a ON ca.agent_id = a.id
       WHERE ca.chat_id = ?`,
      [groupId]
    ));
  }

  /**
   * Persist a system message.
   * @param {string} groupId
   * @param {string} content
   * @param {string} [type='system']
   * @private
   */
  async _saveSystemMessage(groupId, content, type = 'system') {
    const id = uuidv4();
    const now = Date.now();
    await runAsync(
      `INSERT INTO messages (id, chat_id, sender_type, sender_id, content, type, status, created_at)
       VALUES (?, ?, 'system', 'system', ?, ?, 'done', ?)`,
      [id, groupId, content, type, now]
    );
    return id;
  }
}

module.exports = LifecycleService;
