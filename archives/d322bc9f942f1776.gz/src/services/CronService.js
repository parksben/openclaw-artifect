/**
 * CronService.js
 * Manages scheduled cron jobs via OpenClaw Gateway HTTP API.
 */

'use strict';

/**
 * CronService — add, remove, and list cron jobs through GatewayHttp.
 */
class CronService {
  /**
   * @param {import('../gateway/GatewayHttp')} gatewayHttp
   */
  constructor(gatewayHttp) {
    this._http = gatewayHttp;
  }

  /**
   * Add a new cron job.
   * @param {object} params
   * @param {string} params.cron - Cron expression (e.g. "0 9 * * 1") OR use `once` for one-time.
   * @param {string} [params.once] - ISO datetime string for a one-time job (alternative to cron)
   * @param {string} params.prompt - Task prompt to execute
   * @param {string} [params.label] - Human-readable label
   * @param {string} [params.tz] - Timezone (default: Asia/Shanghai)
   * @returns {Promise<{ id: string, [key: string]: any }>}
   */
  async add({ cron, once, prompt, label, tz = 'Asia/Shanghai' }) {
    if (!prompt) throw new Error('CronService.add: prompt is required');
    if (!cron && !once) throw new Error('CronService.add: either cron or once is required');

    const params = { prompt, tz };
    if (cron) params.cron = cron;
    if (once) params.once = once;
    if (label) params.label = label;

    const result = await this._http.invoke('cron_add', params);

    if (!result || !result.id) {
      throw new Error(`CronService.add: unexpected response: ${JSON.stringify(result)}`);
    }
    return result;
  }

  /**
   * Remove a cron job by ID.
   * @param {string} id - Cron job ID
   * @returns {Promise<object>}
   */
  async remove(id) {
    if (!id) throw new Error('CronService.remove: id is required');
    return this._http.invoke('cron_remove', { id });
  }

  /**
   * List all cron jobs.
   * @returns {Promise<Array<object>>}
   */
  async list() {
    const result = await this._http.invoke('cron_list', {});
    if (Array.isArray(result)) return result;
    if (result && Array.isArray(result.jobs)) return result.jobs;
    return result;
  }
}

module.exports = CronService;
