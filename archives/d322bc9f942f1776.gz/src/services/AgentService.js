/**
 * AgentService.js
 * Manages AI Agent employee lifecycle via OpenClaw Gateway tools.
 * Uses GatewayHttp to call: sessions_spawn, sessions_send, sessions_history, subagents(kill)
 */

'use strict';

/**
 * AgentService — spawn, message, query, and kill agent employees.
 */
class AgentService {
  /**
   * @param {import('../gateway/GatewayHttp')} gatewayHttp
   */
  constructor(gatewayHttp) {
    this._http = gatewayHttp;
  }

  /**
   * Spawn a new agent employee (session).
   * @param {object} params
   * @param {string} params.label - Human-readable session label
   * @param {string} params.prompt - Initial system prompt or task description
   * @param {string} [params.model] - Model identifier (optional)
   * @param {object} [params.extra] - Additional parameters passed through
   * @returns {Promise<{ sessionId: string, [key: string]: any }>}
   */
  async spawnEmployee({ label, prompt, model, extra = {} }) {
    if (!label) throw new Error('AgentService.spawnEmployee: label is required');
    if (!prompt) throw new Error('AgentService.spawnEmployee: prompt is required');

    const result = await this._http.invoke('sessions_spawn', {
      label,
      prompt,
      ...(model ? { model } : {}),
      ...extra,
    });

    if (!result || !result.sessionId) {
      throw new Error(`AgentService.spawnEmployee: unexpected response: ${JSON.stringify(result)}`);
    }

    return result;
  }

  /**
   * Send a message to a running agent session.
   * @param {string} sessionId - Target session ID
   * @param {string} message - Message text to deliver
   * @param {object} [extra] - Additional parameters
   * @returns {Promise<object>}
   */
  async sendMessage(sessionId, message, extra = {}) {
    if (!sessionId) throw new Error('AgentService.sendMessage: sessionId is required');
    if (!message) throw new Error('AgentService.sendMessage: message is required');

    return this._http.invoke('sessions_send', {
      sessionId,
      message,
      ...extra,
    });
  }

  /**
   * Retrieve message history for a session.
   * @param {string} sessionId - Target session ID
   * @param {object} [options]
   * @param {number} [options.limit] - Max number of messages to retrieve
   * @returns {Promise<Array<object>>}
   */
  async getHistory(sessionId, { limit } = {}) {
    if (!sessionId) throw new Error('AgentService.getHistory: sessionId is required');

    const params = { sessionId };
    if (limit !== undefined) params.limit = limit;

    const result = await this._http.invoke('sessions_history', params);

    // Normalize: return array directly if result is one, else wrap
    if (Array.isArray(result)) return result;
    if (result && Array.isArray(result.messages)) return result.messages;
    return result;
  }

  /**
   * Kill (terminate) a running agent session.
   * @param {string} sessionId - Session/subagent ID to kill
   * @returns {Promise<object>}
   */
  async killEmployee(sessionId) {
    if (!sessionId) throw new Error('AgentService.killEmployee: sessionId is required');

    return this._http.invoke('subagents', {
      action: 'kill',
      target: sessionId,
    });
  }
}

module.exports = AgentService;
