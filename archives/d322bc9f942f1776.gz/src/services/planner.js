const { allAsync, getAsync } = require('../db');
const { runAgent, saveMessage, parseDocCommands } = require('./agentRunner');

/**
 * Planner-Executor architecture:
 * 1. If a planner agent exists in the chat, planner goes first (analyzes + assigns tasks)
 * 2. Executor agents run concurrently, each with full context (including planner's response)
 * 3. 30% chance each executor asks a follow-up question (max 2 rounds)
 * 4. If no planner, fall back to sequential mode
 */
async function runPlannerExecutor({ chatId, agentIds, history, userMessage, kbContext = '' }) {
  // Load agent rows
  const placeholders = agentIds.map(() => '?').join(',');
  const agents = await allAsync(
    `SELECT * FROM agents WHERE id IN (${placeholders})`,
    agentIds
  );

  // Get project_id for doc command parsing
  const chat = await getAsync('SELECT project_id FROM chats WHERE id = ?', [chatId]);
  const projectId = chat ? chat.project_id : null;

  const planner = agents.find(a => a.role_type === 'planner');
  const executors = agents.filter(a => a.role_type !== 'planner');

  const allReplies = [];

  if (planner) {
    // Step 1: Planner replies first
    const plannerReply = await runAgent(planner.id, planner, chatId, history, userMessage + kbContext);
    allReplies.push(plannerReply);
    if (projectId) await parseDocCommands(plannerReply.content, projectId, planner.id, planner.name);

    // Step 2: Build enriched context for executors (include planner's analysis)
    const enrichedHistory = [
      ...history,
      { sender_type: 'agent', sender_id: planner.id, content: plannerReply.content },
    ];

    // Step 3: Executors run concurrently
    if (executors.length > 0) {
      const executorResults = await Promise.all(
        executors.map(agent => runAgent(agent.id, agent, chatId, enrichedHistory, userMessage + kbContext))
      );
      allReplies.push(...executorResults);
      for (const result of executorResults) {
        const agent = agents.find(a => a.id === result.sender_id) || {};
        if (projectId) await parseDocCommands(result.content, projectId, result.sender_id, agent.name);
      }

      // Step 4: 30% chance follow-up, max 2 rounds
      await runFollowUpRounds({ chatId, executors, history: enrichedHistory, userMessage, maxRounds: 2, projectId, agents });
    }
  } else {
    // Fallback: sequential mode
    for (const agent of agents) {
      const reply = await runAgent(agent.id, agent, chatId, history, userMessage + kbContext);
      allReplies.push(reply);
      if (projectId) await parseDocCommands(reply.content, projectId, agent.id, agent.name);
      history = [...history, { sender_type: 'agent', sender_id: agent.id, content: reply.content }];
    }
  }

  return allReplies;
}

async function runFollowUpRounds({ chatId, executors, history, userMessage, maxRounds, projectId, agents = [] }) {
  for (let round = 0; round < maxRounds; round++) {
    const followUps = executors.filter(() => Math.random() < 0.3);
    if (followUps.length === 0) break;

    const results = await Promise.all(
      followUps.map(agent => {
        const followUpPrompt = `[Follow-up round ${round + 1}] ${userMessage}`;
        return runAgent(agent.id, agent, chatId, history, followUpPrompt);
      })
    );

    // Append follow-up replies to history for next round
    for (const r of results) {
      const agent = agents.find(a => a.id === r.sender_id) || {};
      if (projectId) await parseDocCommands(r.content, projectId, r.sender_id, agent.name);
      history = [...history, { sender_type: 'agent', sender_id: r.sender_id || 'agent', content: r.content }];
    }
  }
}

module.exports = { runPlannerExecutor };
