const { v4: uuidv4 } = require('uuid');
const { execSync, spawn } = require('child_process');
const { runAsync, allAsync, getAsync } = require('../db');
const events = require('../events');

// Mock response templates by role
const MOCK_RESPONSES = {
  planner: (userMsg) => `【规划分析】

收到你的需求：「${userMsg}」

我来拆解一下任务：
1. **需求分析**：明确目标和验收标准
2. **任务拆解**：将需求拆分为可执行的子任务
3. **资源分配**：根据团队成员特长分配工作
4. **里程碑设定**：确定关键节点和交付时间

@Coder 请负责技术实现部分
@Designer 请负责界面设计
@Analyst 请进行数据层面的分析

我们开始吧！`,

  coder: (userMsg) => `【技术方案】

针对「${userMsg}」，我的技术思路如下：

\`\`\`
// 核心实现思路
// 1. 选型：根据需求选择合适的技术栈
// 2. 架构：清晰的模块划分
// 3. 实现：高质量、可维护的代码
\`\`\`

我会注意：
- 代码复用性和可维护性
- 错误处理和边界情况
- 性能优化

有具体的技术细节可以继续讨论。`,

  designer: (userMsg) => `【设计思路】

关于「${userMsg}」的设计方案：

**用户体验核心原则：**
- 简洁直观，降低认知负担
- 一致性，保持视觉统一
- 反馈及时，操作结果可感知

**初步方案：**
1. 信息架构梳理
2. 交互流程设计
3. 视觉规范制定

我来出一版原型草图，稍后分享。`,

  analyst: (userMsg) => `【数据分析】

对于「${userMsg}」，从数据角度来看：

**关键指标：**
- 用户行为数据
- 转化漏斗分析
- 留存和活跃度

**分析框架：**
1. 现状诊断：数据现在在哪里
2. 问题定位：差距在哪里
3. 原因分析：为什么会这样
4. 行动建议：怎么改进

我需要更多背景数据来做深入分析，你能提供相关数据源吗？`,

  writer: (userMsg) => `【文案建议】

关于「${userMsg}」，我的文案思路：

**核心信息提炼：**
- 用户痛点：...
- 产品价值：...
- 行动召唤：...

**文案方向（3个版本）：**

版本A（理性诉求）：强调功能和效率
版本B（情感共鸣）：强调体验和感受
版本C（社会认同）：强调用户口碑

让我知道你偏好哪个方向，我来精细打磨。`,

  default: (userMsg) => `我收到了你的消息：「${userMsg}」\n\n让我来处理这个任务...`,
};

// Save a message to DB and emit SSE event
async function saveMessage({ chatId, senderType, senderId, content, thinking, status = 'done', type = 'text', file_url, file_name, file_size, duration }) {
  const id = uuidv4();
  const now = Date.now();
  await runAsync(
    `INSERT INTO messages (id, chat_id, sender_type, sender_id, content, thinking, status, type, file_url, file_name, file_size, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, chatId, senderType, senderId, content || '', thinking || null, status, type, file_url || null, file_name || null, file_size || null, now]
  );
  const msg = { id, chat_id: chatId, sender_type: senderType, sender_id: senderId, content, thinking, status, type, file_url, file_name, file_size, duration, created_at: now };
  events.emit(chatId, { type: 'message', data: msg });
  return msg;
}

// Update message content (for streaming simulation)
async function updateMessage(id, chatId, content, status = 'done') {
  await runAsync('UPDATE messages SET content = ?, status = ? WHERE id = ?', [content, status, id]);
  events.emit(chatId, { type: 'message_update', data: { id, content, status } });
}

/**
 * Run an agent reply via OpenClaw CLI.
 * Uses: openclaw agent --agent <id> --message <text> --json
 *
 * Falls back to mock response if OpenClaw is unavailable.
 */
async function runAgent(agentId, agentRow, chatId, history, userMessage, onChunk, onDone) {
  const msgId = uuidv4();
  const now = Date.now();

  // Insert placeholder message in streaming state
  await runAsync(
    `INSERT INTO messages (id, chat_id, sender_type, sender_id, content, thinking, status, created_at)
     VALUES (?, ?, 'agent', ?, '', NULL, 'streaming', ?)`,
    [msgId, chatId, agentId, now]
  );
  events.emit(chatId, {
    type: 'message',
    data: { id: msgId, chat_id: chatId, sender_type: 'agent', sender_id: agentId, content: '', status: 'streaming', created_at: now },
  });

  let fullContent = '';

  try {
    // Build context message: include recent history (last 6 messages) as context prefix
    // --- 上下文构建 ---
    // 1) 群消息历史（最近 20 条，足够让刚加入的 Agent 了解项目进展）
    let historyText = '';
    if (history && history.length > 0) {
      const recent = history.slice(-20);
      historyText = recent.map(m => {
        const role = m.sender_type === 'user' ? '用户' : m.sender_id;
        const body = (m.type === 'audio') ? '[语音消息]' : (m.content || '');
        return `[${role}]: ${body}`;
      }).join('\n');
    }

    // 2) 工作区文档索引（让 Agent 知道有哪些文档可以读）
    let workspaceDocs = '';
    try {
      const fs = require('fs');
      const docsDir = path.join(process.env.WORKSPACE_DIR || process.env.HOME + '/.niuma/workspace', 'docs');
      if (fs.existsSync(docsDir)) {
        const files = fs.readdirSync(docsDir).filter(f => f.endsWith('.md')).slice(0, 20);
        if (files.length > 0) {
          workspaceDocs = '\n\n## 工作区文档（可通过文件读取工具访问）\n' +
            files.map(f => `- docs/${f}`).join('\n');
        }
      }
    } catch (_) {}

    // 3) 组装完整消息
    const contextSections = [];
    if (workspaceDocs) contextSections.push(`## 项目文档索引${workspaceDocs}`);
    if (historyText) contextSections.push(`## 近期群消息记录\n${historyText}`);
    contextSections.push(`## 当前消息\n${userMessage}`);

    const fullMessage = contextSections.length > 1
      ? contextSections.join('\n\n---\n\n')
      : userMessage;

    // Model selection: agent instance override > role template preferredModel > global default
    // thinking level: same priority chain
    const thinkingLevel = agentRow.thinking_level || 'low';
    const modelOverride = agentRow.model_override || null;

    // Build CLI args
    const cliArgs = [
      'agent',
      '--agent', agentId,
      '--message', fullMessage,
      '--thinking', thinkingLevel,
      '--json',
    ];
    if (modelOverride) {
      cliArgs.push('--model', modelOverride);
    }

    const result = execSync(
      `openclaw ${cliArgs.map(a => JSON.stringify(a)).join(' ')}`,
      { timeout: 60000, encoding: 'utf8' }
    );

    const parsed = JSON.parse(result);
    const payloads = parsed?.result?.payloads || [];
    fullContent = payloads.map(p => p.text || '').join('').trim();

    if (!fullContent) throw new Error('Empty response from OpenClaw');

  } catch (err) {
    console.error(`[agentRunner] OpenClaw call failed for ${agentId}:`, err.message);
    // Fallback to mock
    const roleType = agentRow.role_type || 'default';
    const template = MOCK_RESPONSES[roleType] || MOCK_RESPONSES.default;
    fullContent = template(userMessage);
  }

  // Stream the content in chunks for real-time feel
  const chunks = fullContent.match(/.{1,30}/gs) || [fullContent];
  let accumulated = '';
  for (const chunk of chunks) {
    await new Promise(r => setTimeout(r, 15));
    accumulated += chunk;
    if (onChunk) onChunk(chunk);
    events.emit(chatId, { type: 'message_chunk', data: { id: msgId, chunk, content: accumulated } });
  }

  await updateMessage(msgId, chatId, accumulated, 'done');

  // --- 任务完成打分触发 ---
  // 当 Agent 回复中包含明确的任务完成标志时，发起互评邀请
  const completionSignals = ['✅', '已完成', '完成了', '开发完成', '设计完成', '分析完成', '测试通过', '已就绪', '已上线'];
  const isTaskDone = completionSignals.some(sig => accumulated.includes(sig));
  if (isTaskDone) {
    // 异步触发，不阻塞当前回复
    setImmediate(() => triggerPeerReview(chatId, agentId, msgId, accumulated).catch(console.error));
  }
  if (onDone) onDone(accumulated);

  return { id: msgId, content: accumulated };
}

/**
 * Parse agent-generated doc commands and persist them to knowledge_docs.
 */
async function parseDocCommands(content, projectId, agentId, agentName) {
  if (!projectId) return;

  const createReg = /<!--\s*create_doc:\s*(\{.*?\})\s*-->([\s\S]*?)<!--\s*\/create_doc\s*-->/g;
  const updateReg = /<!--\s*update_doc:\s*(\{.*?\})\s*-->([\s\S]*?)<!--\s*\/update_doc\s*-->/g;

  let match;
  while ((match = createReg.exec(content)) !== null) {
    try {
      const meta = JSON.parse(match[1]);
      const docContent = match[2].trim();
      await runAsync(
        'INSERT INTO knowledge_docs (project_id, title, content, author_type, author_id, author_name) VALUES (?, ?, ?, ?, ?, ?)',
        [projectId, meta.title || 'Untitled', docContent, 'agent', agentId, agentName || 'Agent']
      );
      console.log(`[kb] Agent created doc: "${meta.title}" in project ${projectId}`);
    } catch (e) {
      console.error('[kb] parseDocCommands create error:', e.message);
    }
  }

  while ((match = updateReg.exec(content)) !== null) {
    try {
      const meta = JSON.parse(match[1]);
      const docContent = match[2].trim();
      if (!meta.id) continue;
      await runAsync(
        'UPDATE knowledge_docs SET content = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND project_id = ?',
        [docContent, meta.id, projectId]
      );
      console.log(`[kb] Agent updated doc id=${meta.id} in project ${projectId}`);
    } catch (e) {
      console.error('[kb] parseDocCommands update error:', e.message);
    }
  }
}


// ============================================================
// 同伴互评系统（Peer Review & Score Feedback）
// ============================================================

// getAsync / allAsync / runAsync already imported at top of file

/**
 * 触发互评邀请：向群内其他 Agent 发出打分请求
 * 打分维度：准确性 / 完整性 / 效率（是否简洁）/ 协作性
 */
async function triggerPeerReview(chatId, authorAgentId, msgId, taskSummary) {
  // 找本群其他 Agent（最多邀请 2 个，避免刷屏）
  const agents = await allAsync(
    `SELECT DISTINCT sender_id FROM messages
     WHERE chat_id = ? AND sender_type = 'agent' AND sender_id != ?
     ORDER BY created_at DESC LIMIT 2`,
    [chatId, authorAgentId]
  );
  if (!agents.length) return;

  const reviewPrompt = `
[系统通知] @${authorAgentId} 刚完成了一项任务，请你对这次输出做简短评价（50字以内）并打分：

任务摘要：${taskSummary.slice(0, 200)}${taskSummary.length > 200 ? '…' : ''}

请按以下格式回复：
⭐ 综合评分：X/5
💬 评价：[你的评价]
💡 改进建议：[一句话]（如果满分可以写「无」）
`.trim();

  for (const { sender_id: reviewerId } of agents) {
    try {
      const reviewerRow = await getAsync('SELECT * FROM agents WHERE id = ?', [reviewerId]);
      if (!reviewerRow) continue;
      // 用低 token budget 调用，这是辅助任务
      const cliArgs = ['agent', '--agent', reviewerId, '--message', reviewPrompt, '--thinking', 'off', '--json'];
      if (reviewerRow.model_override) cliArgs.push('--model', reviewerRow.model_override);
      const result = execSync(
        `openclaw ${cliArgs.map(a => JSON.stringify(a)).join(' ')}`,
        { timeout: 30000, encoding: 'utf8' }
      );
      const parsed = JSON.parse(result);
      const reviewText = (parsed?.result?.payloads || []).map(p => p.text || '').join('').trim();
      if (!reviewText) continue;

      // 存储评分到 peer_reviews 表（顺便记录给反馈学习用）
      await runAsync(
        `INSERT OR IGNORE INTO peer_reviews (id, chat_id, msg_id, author_id, reviewer_id, review_text, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [uuidv4(), chatId, msgId, authorAgentId, reviewerId, reviewText, Date.now()]
      );

      // 把评分作为消息发到群里
      await saveMessage({
        chatId,
        senderType: 'agent',
        senderId: reviewerId,
        content: reviewText,
        type: 'text',
      });
      events.emit(chatId, { type: 'peer_review', data: { authorId: authorAgentId, reviewerId, msgId } });
    } catch (e) {
      console.warn(`[peerReview] ${reviewerId} failed:`, e.message);
    }
  }
}

module.exports = { runAgent, saveMessage, parseDocCommands, triggerPeerReview };



