/**
 * GroupOrchestrator.js
 * Orchestrates group chat interactions between users and AI agent employees.
 * Handles @mention parsing, context building, rate limiting, and recursive agent calls.
 */

'use strict';

const { getAsync, allAsync, runAsync } = require('../db');
const { emit } = require('../events');
const { v4: uuidv4 } = require('uuid');

/** Max recursion depth for agent-to-agent interactions */
const MAX_DEPTH = 8;
/** Max agent messages per group per minute */
const RATE_LIMIT_PER_MINUTE = 30;
/** Single agent call timeout in ms */
const AGENT_TIMEOUT_MS = 60_000;

/**
 * In-memory rate counter: groupId -> { count, windowStart }
 * @type {Map<string, { count: number, windowStart: number }>}
 */
const rateCounters = new Map();

/**
 * GroupOrchestrator — routes messages to AI employees based on @mentions.
 */
class GroupOrchestrator {
  /**
   * @param {import('./AgentService')} agentService
   * @param {import('ws').Server} [wss] - Optional WebSocket server for typing events
   */
  constructor(agentService, wss = null) {
    this._agentService = agentService;
    this._wss = wss;
  }

  /**
   * Entry point: handle a message in a group (from user or agent).
   * @param {object} params
   * @param {string} params.groupId - chat/group ID (maps to chats.id)
   * @param {'user'|'agent'} params.fromType - sender type
   * @param {string} params.fromId - sender ID
   * @param {string} params.content - message content
   * @param {number} [params.depth=0] - recursion depth
   * @returns {Promise<void>}
   */
  async handleMessage({ groupId, fromType, fromId, content, depth = 0 }) {
    // Load group (chat) and check status
    const group = await getAsync('SELECT * FROM chats WHERE id = ?', [groupId]);
    if (!group) throw new Error(`GroupOrchestrator: group ${groupId} not found`);

    // Use group.status field; default running if not set
    const status = group.status || 'running';
    if (status !== 'running') {
      return; // silently skip when paused/stopped
    }

    // Depth guard
    if (depth > MAX_DEPTH) {
      await this._saveSystemMessage(groupId, '讨论已达轮次上限，本轮对话结束。');
      emit(groupId, { type: 'system', content: '讨论已达轮次上限，本轮对话结束。' });
      return;
    }

    // Rate limit check
    if (!this._checkRateLimit(groupId)) {
      await this._saveSystemMessage(groupId, '群内发言频率过高，已暂停 Agent 响应（每分钟上限 30 条）。');
      emit(groupId, { type: 'system', content: '群内发言频率过高，已暂停 Agent 响应。' });
      return;
    }

    const mentions = this.parseMentions(content);
    if (mentions.length === 0) return; // no mentions, nothing to dispatch

    // Load all employees in this group
    const employees = await allAsync(
      `SELECT ca.agent_id, a.name, a.role_type, a.bio, a.system_prompt
       FROM chat_agents ca
       JOIN agents a ON ca.agent_id = a.id
       WHERE ca.chat_id = ?`,
      [groupId]
    );

    // Map name -> employee
    const employeeByName = new Map(employees.map(e => [e.name, e]));

    // Resolve mentioned employees
    const targets = mentions
      .map(name => employeeByName.get(name))
      .filter(Boolean);

    if (targets.length === 0) return;

    // Parallel dispatch
    await Promise.all(
      targets.map(emp => this._dispatchToEmployee({
        group,
        employee: emp,
        triggerFromId: fromId,
        triggerFromType: fromType,
        triggerContent: content,
        depth,
      }))
    );
  }

  /**
   * Parse @mentions from message content.
   * Supports Chinese names and latin names (e.g. @张三-PM, @Alice-Dev).
   * @param {string} content
   * @returns {string[]} list of mentioned names without '@'
   */
  parseMentions(content) {
    const regex = /@([\u4e00-\u9fa5\w][\u4e00-\u9fa5\w-]*)/g;
    const names = [];
    let m;
    while ((m = regex.exec(content)) !== null) {
      names.push(m[1]);
    }
    return [...new Set(names)];
  }

  /**
   * Build the context string for an agent call.
   * @param {string} groupId
   * @param {string} employeeId - agent_id of the target employee
   * @param {string} triggerContent - the message content that triggered the call
   * @param {string} triggerFromName - display name of the trigger sender
   * @returns {Promise<string>}
   */
  async buildContext(groupId, employeeId, triggerContent, triggerFromName = '用户') {
    const group = await getAsync('SELECT * FROM chats WHERE id = ?', [groupId]);
    const employee = await getAsync('SELECT * FROM agents WHERE id = ?', [employeeId]);
    if (!group || !employee) throw new Error('GroupOrchestrator.buildContext: group or employee not found');

    // Recent messages (last 10)
    const recent = await allAsync(
      `SELECT m.sender_type, m.sender_id, m.content, a.name as agent_name
       FROM messages m
       LEFT JOIN agents a ON m.sender_type = 'agent' AND m.sender_id = a.id
       WHERE m.chat_id = ?
       ORDER BY m.created_at DESC
       LIMIT 10`,
      [groupId]
    );
    recent.reverse();

    const historyLines = recent.map(msg => {
      const label = msg.sender_type === 'agent' ? `[${msg.agent_name || msg.sender_id}]` : '[用户]';
      return `${label}: ${msg.content}`;
    }).join('\n');

    const groupName = group.title || groupId;
    const { name, role_type: role } = employee;

    return `你是「${name}」，职位：${role}，在「${groupName}」工作。

== 群近期对话（最近10条）==
${historyLines || '（暂无对话记录）'}

== 当前指令 ==
${triggerFromName} @你：${triggerContent}

请以${name}的身份回复，在群里发言。
如果需要其他同事协助，可以直接 @他们的名字。`;
  }

  /**
   * Broadcast typing indicator to WebSocket clients.
   * @param {string} groupId
   * @param {string} employeeId
   * @param {boolean} isTyping
   */
  broadcastTyping(groupId, employeeId, isTyping) {
    if (!this._wss) return;
    const payload = JSON.stringify({ type: 'typing', groupId, employeeId, isTyping });
    this._wss.clients.forEach(client => {
      if (client.readyState === 1 /* OPEN */ && client.groupId === groupId) {
        client.send(payload);
      }
    });
    // Also emit on SSE bus
    emit(groupId, { type: 'typing', employeeId, isTyping });
  }

  // ──────────────────────────────────────────────────────────────
  // Private helpers
  // ──────────────────────────────────────────────────────────────

  /**
   * Check & update the rate counter for a group.
   * Returns true if under limit, false if exceeded.
   * @param {string} groupId
   * @returns {boolean}
   */
  _checkRateLimit(groupId) {
    const now = Date.now();
    const window = 60_000;
    let counter = rateCounters.get(groupId);
    if (!counter || now - counter.windowStart > window) {
      counter = { count: 0, windowStart: now };
    }
    if (counter.count >= RATE_LIMIT_PER_MINUTE) {
      rateCounters.set(groupId, counter);
      return false;
    }
    counter.count += 1;
    rateCounters.set(groupId, counter);
    return true;
  }

  /**
   * Dispatch a message to a single employee agent.
   * @private
   */
  async _dispatchToEmployee({ group, employee, triggerFromId, triggerFromType, triggerContent, depth }) {
    const groupId = group.id;

    // Determine sender display name
    let triggerFromName = '用户';
    if (triggerFromType === 'agent') {
      const sender = await getAsync('SELECT name FROM agents WHERE id = ?', [triggerFromId]);
      if (sender) triggerFromName = sender.name;
    }

    const context = await this.buildContext(groupId, employee.agent_id, triggerContent, triggerFromName);

    this.broadcastTyping(groupId, employee.agent_id, true);

    let reply;
    try {
      // Spawn or reuse session — here we call sendMessage with context as prompt
      // (AgentService.spawnEmployee is for long-lived sessions; use sendMessage if session exists)
      // For simplicity, spawn a fresh one-shot session per invocation
      const session = await Promise.race([
        this._agentService.spawnEmployee({
          label: `${group.title || groupId}/${employee.name}`,
          prompt: employee.system_prompt || `你是${employee.name}，职位：${employee.role_type}。`,
        }),
        _timeout(AGENT_TIMEOUT_MS, `Agent ${employee.name} timed out`),
      ]);

      const result = await Promise.race([
        this._agentService.sendMessage(session.sessionId, context),
        _timeout(AGENT_TIMEOUT_MS, `Agent ${employee.name} response timed out`),
      ]);

      reply = (result && (result.reply || result.content || result.text)) || null;
    } catch (err) {
      this.broadcastTyping(groupId, employee.agent_id, false);
      console.error(`[GroupOrchestrator] agent call failed for ${employee.name}:`, err.message);
      return;
    }

    this.broadcastTyping(groupId, employee.agent_id, false);

    if (!reply) return;

    // Save reply to DB
    const msgId = uuidv4();
    const now = Date.now();
    await runAsync(
      `INSERT INTO messages (id, chat_id, sender_type, sender_id, content, status, created_at)
       VALUES (?, ?, 'agent', ?, ?, 'done', ?)`,
      [msgId, groupId, employee.agent_id, reply, now]
    );

    // Emit on SSE bus
    emit(groupId, {
      type: 'message',
      id: msgId,
      sender_type: 'agent',
      sender_id: employee.agent_id,
      sender_name: employee.name,
      content: reply,
      created_at: now,
    });

    // Recurse for @mentions in the reply
    await this.handleMessage({
      groupId,
      fromType: 'agent',
      fromId: employee.agent_id,
      content: reply,
      depth: depth + 1,
    });
  }

  /**
   * Persist a system message to the DB and emit on SSE bus.
   * @param {string} groupId
   * @param {string} content
   */
  async _saveSystemMessage(groupId, content) {
    const id = uuidv4();
    const now = Date.now();
    await runAsync(
      `INSERT INTO messages (id, chat_id, sender_type, sender_id, content, type, status, created_at)
       VALUES (?, ?, 'system', 'system', ?, 'system', 'done', ?)`,
      [id, groupId, content, now]
    );
    emit(groupId, { type: 'system', id, content, created_at: now });
  }
}

/**
 * Returns a promise that rejects after `ms` milliseconds.
 * @param {number} ms
 * @param {string} message
 * @returns {Promise<never>}
 */
function _timeout(ms, message) {
  return new Promise((_, reject) => setTimeout(() => reject(new Error(message)), ms));
}

module.exports = GroupOrchestrator;
