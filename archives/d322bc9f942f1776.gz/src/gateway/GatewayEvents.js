/**
 * GatewayEvents.js
 * Listens for event frames from GatewayClient and dispatches them via EventEmitter.
 * Event frames have the shape: { type: "event", event: "<name>", payload: {...} }
 */

'use strict';

const EventEmitter = require('events');

/**
 * GatewayEvents — re-emits typed Gateway events for easy subscription.
 *
 * Usage:
 *   const events = new GatewayEvents(gatewayClient);
 *   events.on('sessions.update', (payload) => { ... });
 *   events.on('agent.message', (payload) => { ... });
 *   events.onAny((eventName, payload) => { ... });  // catch-all
 */
class GatewayEvents extends EventEmitter {
  /**
   * @param {import('./GatewayClient')} gatewayClient
   */
  constructor(gatewayClient) {
    super();
    this._client = gatewayClient;
    this._client.on('message', (frame) => this._handleMessage(frame));
  }

  /**
   * Register a catch-all listener that fires for every Gateway event.
   * @param {(eventName: string, payload: object) => void} listener
   */
  onAny(listener) {
    this.on('__any__', listener);
  }

  /**
   * Remove a catch-all listener.
   * @param {(eventName: string, payload: object) => void} listener
   */
  offAny(listener) {
    this.off('__any__', listener);
  }

  // ─── private ────────────────────────────────────────────────────────────────

  _handleMessage(frame) {
    if (frame.type !== 'event' || !frame.event) return;

    const { event, payload } = frame;

    // Dispatch specific event
    this.emit(event, payload);

    // Dispatch catch-all
    this.emit('__any__', event, payload);
  }
}

module.exports = GatewayEvents;
