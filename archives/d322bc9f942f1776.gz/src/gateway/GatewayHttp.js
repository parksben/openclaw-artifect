/**
 * GatewayHttp.js
 * HTTP client for OpenClaw Gateway REST endpoints.
 * Primary use: POST /tools/invoke with Authorization: Bearer <token>
 */

'use strict';

const https = require('https');
const http = require('http');
const { URL } = require('url');

/**
 * GatewayHttp — thin HTTP wrapper for Gateway tool invocations.
 */
class GatewayHttp {
  /**
   * @param {object} [options]
   * @param {string} [options.baseUrl] - Gateway base URL (http/https). Derived from WS URL if not set.
   * @param {string} [options.token] - Bearer token
   */
  constructor(options = {}) {
    const wsUrl = options.baseUrl || process.env.OPENCLAW_GATEWAY_URL || 'ws://localhost:18789';
    // Convert ws:// → http://, wss:// → https://
    this._baseUrl = wsUrl.replace(/^ws:\/\//, 'http://').replace(/^wss:\/\//, 'https://');
    this._token = options.token || process.env.OPENCLAW_GATEWAY_TOKEN || '';
  }

  /**
   * Invoke a Gateway tool via HTTP POST /tools/invoke.
   * @param {string} tool - Tool name (e.g. "sessions_spawn")
   * @param {object} [params] - Tool parameters
   * @returns {Promise<object>} Parsed response body
   */
  async invoke(tool, params = {}) {
    const body = JSON.stringify({ tool, params });
    return this._post('/tools/invoke', body);
  }

  /**
   * Generic POST request.
   * @param {string} pathname - URL path (e.g. "/tools/invoke")
   * @param {string} body - JSON string body
   * @returns {Promise<object>}
   */
  _post(pathname, body) {
    return new Promise((resolve, reject) => {
      const urlStr = this._baseUrl + pathname;
      let parsed;
      try {
        parsed = new URL(urlStr);
      } catch (err) {
        return reject(new Error(`GatewayHttp: invalid URL "${urlStr}": ${err.message}`));
      }

      const isHttps = parsed.protocol === 'https:';
      const lib = isHttps ? https : http;

      const options = {
        hostname: parsed.hostname,
        port: parsed.port || (isHttps ? 443 : 80),
        path: parsed.pathname + (parsed.search || ''),
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(body),
          'Authorization': `Bearer ${this._token}`,
        },
      };

      const req = lib.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => { data += chunk; });
        res.on('end', () => {
          if (res.statusCode < 200 || res.statusCode >= 300) {
            return reject(
              new Error(`GatewayHttp: HTTP ${res.statusCode} from ${urlStr}: ${data}`)
            );
          }
          try {
            resolve(JSON.parse(data));
          } catch {
            resolve(data);
          }
        });
      });

      req.on('error', (err) => {
        reject(new Error(`GatewayHttp: request failed: ${err.message}`));
      });

      req.write(body);
      req.end();
    });
  }
}

module.exports = GatewayHttp;
