/**
 * GatewayClient.js
 * WebSocket long-connection to OpenClaw Gateway.
 * Handles challenge/connect handshake, exponential-backoff reconnect, and 15s heartbeat tick.
 */

'use strict';

const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');

const DEVICE_KEY_PATH = path.resolve(process.cwd(), '.gateway-device-key');

/**
 * Load or generate a persistent ed25519 key pair for device identity.
 * @returns {{ privateKey: Buffer, publicKey: Buffer, deviceId: string }}
 */
function loadOrCreateDeviceKey() {
  if (fs.existsSync(DEVICE_KEY_PATH)) {
    const raw = JSON.parse(fs.readFileSync(DEVICE_KEY_PATH, 'utf8'));
    return {
      privateKey: Buffer.from(raw.privateKey, 'base64'),
      publicKey: Buffer.from(raw.publicKey, 'base64'),
      deviceId: raw.deviceId,
    };
  }

  const { privateKey, publicKey } = crypto.generateKeyPairSync('ed25519');
  const privDer = privateKey.export({ type: 'pkcs8', format: 'der' });
  const pubDer = publicKey.export({ type: 'spki', format: 'der' });

  // Raw 32-byte keys from DER: last 32 bytes for private (pkcs8), last 32 for public (spki)
  const privRaw = privDer.slice(-32);
  const pubRaw = pubDer.slice(-32);
  const deviceId = 'niuma-' + crypto.randomBytes(8).toString('hex');

  const keyData = {
    deviceId,
    privateKey: privRaw.toString('base64'),
    publicKey: pubRaw.toString('base64'),
  };
  fs.writeFileSync(DEVICE_KEY_PATH, JSON.stringify(keyData, null, 2), { mode: 0o600 });

  return { privateKey: privRaw, publicKey: pubRaw, deviceId };
}

/**
 * Sign the connect payload using ed25519.
 * @param {Buffer} privKeyRaw - 32-byte raw private key
 * @param {object} payload
 * @returns {string} base64 signature
 */
function signPayload(privKeyRaw, payload) {
  const message = Buffer.from(JSON.stringify(payload), 'utf8');
  // Node crypto requires DER-encoded PKCS8 for ed25519 sign
  // Build PKCS8 DER manually: header (16 bytes) + raw key (32 bytes)
  const pkcs8Header = Buffer.from(
    '302e020100300506032b657004220420',
    'hex'
  );
  const pkcs8Der = Buffer.concat([pkcs8Header, privKeyRaw]);
  const privateKey = crypto.createPrivateKey({ key: pkcs8Der, format: 'der', type: 'pkcs8' });
  const sig = crypto.sign(null, message, privateKey);
  return sig.toString('base64');
}

/**
 * GatewayClient — manages WS connection lifecycle.
 *
 * Emits:
 *   'connected'  — after successful handshake
 *   'disconnected' — when connection closes
 *   'message'    — every raw parsed frame
 *   'error'      — on ws error
 */
class GatewayClient extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {string} [options.url] - Gateway WebSocket URL
   * @param {string} [options.token] - Auth token
   */
  constructor(options = {}) {
    super();
    this.url = options.url || process.env.OPENCLAW_GATEWAY_URL || 'ws://localhost:18789';
    this.token = options.token || process.env.OPENCLAW_GATEWAY_TOKEN || '';
    this._ws = null;
    this._heartbeatTimer = null;
    this._reconnectTimer = null;
    this._reconnectAttempt = 0;
    this._connected = false;
    this._destroyed = false;
    this._deviceKey = loadOrCreateDeviceKey();
  }

  /** @returns {boolean} */
  get isConnected() {
    return this._connected;
  }

  /**
   * Connect to Gateway. Resolves when handshake completes.
   * @returns {Promise<void>}
   */
  connect() {
    return new Promise((resolve, reject) => {
      if (this._destroyed) return reject(new Error('GatewayClient has been destroyed'));

      const ws = new WebSocket(this.url);
      this._ws = ws;

      const onceError = (err) => {
        ws.removeEventListener('open', onceOpen);
        reject(new Error(`GatewayClient WS error: ${err.message}`));
      };

      const onceOpen = () => {
        ws.removeEventListener('error', onceError);
      };

      ws.once('open', onceOpen);
      ws.once('error', onceError);

      ws.on('message', (data) => {
        let frame;
        try {
          frame = JSON.parse(data.toString());
        } catch {
          return; // ignore non-JSON
        }

        this.emit('message', frame);

        // Handle challenge
        if (frame.type === 'event' && frame.event === 'connect.challenge') {
          this._handleChallenge(frame.payload)
            .then(() => {
              this._reconnectAttempt = 0;
              this._connected = true;
              this._startHeartbeat();
              this.emit('connected');
              resolve();
            })
            .catch((err) => {
              this.emit('error', err);
              reject(err);
            });
        }
      });

      ws.on('close', () => {
        this._connected = false;
        this._stopHeartbeat();
        this.emit('disconnected');
        if (!this._destroyed) {
          this._scheduleReconnect();
        }
      });

      ws.on('error', (err) => {
        this.emit('error', err);
      });
    });
  }

  /**
   * Send a raw object as JSON over the WebSocket.
   * @param {object} frame
   */
  send(frame) {
    if (!this._ws || this._ws.readyState !== WebSocket.OPEN) {
      throw new Error('GatewayClient: WebSocket is not open');
    }
    this._ws.send(JSON.stringify(frame));
  }

  /**
   * Gracefully destroy and stop reconnecting.
   */
  destroy() {
    this._destroyed = true;
    this._stopHeartbeat();
    if (this._reconnectTimer) clearTimeout(this._reconnectTimer);
    if (this._ws) this._ws.terminate();
  }

  // ─── private ────────────────────────────────────────────────────────────────

  async _handleChallenge({ nonce, ts }) {
    const { privateKey, publicKey, deviceId } = this._deviceKey;
    const signedAt = Date.now();

    const sigPayload = {
      deviceId,
      platform: 'linux',
      role: 'operator',
      scopes: ['operator.read', 'operator.write'],
      token: this.token,
      nonce,
      signedAt,
    };

    const signature = signPayload(privateKey, sigPayload);

    const connectReq = {
      type: 'req',
      id: uuidv4(),
      method: 'connect',
      params: {
        minProtocol: 3,
        maxProtocol: 3,
        client: {
          id: 'niuma-server',
          version: '1.0.0',
          platform: 'linux',
          mode: 'operator',
        },
        role: 'operator',
        scopes: ['operator.read', 'operator.write'],
        caps: [],
        commands: [],
        permissions: {},
        auth: { token: this.token },
        locale: 'zh-CN',
        userAgent: 'niuma-server/1.0.0',
        device: {
          id: deviceId,
          publicKey: publicKey.toString('base64'),
          signature,
          signedAt,
          nonce,
        },
      },
    };

    // Wait for hello-ok response
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this.removeListener('message', onMessage);
        reject(new Error('GatewayClient: connect handshake timeout'));
      }, 10000);

      const onMessage = (frame) => {
        if (
          frame.type === 'res' &&
          frame.ok === true &&
          frame.payload?.type === 'hello-ok'
        ) {
          clearTimeout(timeout);
          this.removeListener('message', onMessage);
          resolve();
        } else if (frame.type === 'res' && frame.ok === false) {
          clearTimeout(timeout);
          this.removeListener('message', onMessage);
          reject(new Error(`GatewayClient: connect rejected: ${JSON.stringify(frame.payload)}`));
        }
      };

      this.on('message', onMessage);
      this._ws.send(JSON.stringify(connectReq));
    });
  }

  _startHeartbeat() {
    this._heartbeatTimer = setInterval(() => {
      if (this._ws && this._ws.readyState === WebSocket.OPEN) {
        try {
          this._ws.send(JSON.stringify({ type: 'req', id: uuidv4(), method: 'tick' }));
        } catch {
          // ignore tick errors
        }
      }
    }, 15000);
  }

  _stopHeartbeat() {
    if (this._heartbeatTimer) {
      clearInterval(this._heartbeatTimer);
      this._heartbeatTimer = null;
    }
  }

  _scheduleReconnect() {
    const delay = Math.min(1000 * Math.pow(2, this._reconnectAttempt), 60000);
    this._reconnectAttempt++;
    this._reconnectTimer = setTimeout(() => {
      this.connect().catch(() => {}); // reconnect loop
    }, delay);
  }
}

module.exports = GatewayClient;
