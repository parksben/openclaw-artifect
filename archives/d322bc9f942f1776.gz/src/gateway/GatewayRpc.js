/**
 * GatewayRpc.js
 * Request/response wrapper over GatewayClient.
 * Sends a req frame and waits for a matching res frame (matched by id).
 * Default timeout: 30s.
 */

'use strict';

const { v4: uuidv4 } = require('uuid');

const DEFAULT_TIMEOUT_MS = 30000;

/**
 * GatewayRpc — wraps GatewayClient with request/response semantics.
 */
class GatewayRpc {
  /**
   * @param {import('./GatewayClient')} gatewayClient
   */
  constructor(gatewayClient) {
    this._client = gatewayClient;
    /** @type {Map<string, { resolve: Function, reject: Function, timer: NodeJS.Timeout }>} */
    this._pending = new Map();

    this._client.on('message', (frame) => this._handleMessage(frame));
  }

  /**
   * Send a request and wait for the response.
   * @param {string} method - RPC method name
   * @param {object} [params] - Request parameters
   * @param {number} [timeoutMs] - Timeout in milliseconds (default 30s)
   * @returns {Promise<object>} Resolved payload
   */
  call(method, params = {}, timeoutMs = DEFAULT_TIMEOUT_MS) {
    return new Promise((resolve, reject) => {
      const id = uuidv4();
      const frame = { type: 'req', id, method, params };

      const timer = setTimeout(() => {
        this._pending.delete(id);
        reject(new Error(`GatewayRpc: timeout waiting for response to method "${method}" (id=${id})`));
      }, timeoutMs);

      this._pending.set(id, { resolve, reject, timer });

      try {
        this._client.send(frame);
      } catch (err) {
        clearTimeout(timer);
        this._pending.delete(id);
        reject(new Error(`GatewayRpc: failed to send request: ${err.message}`));
      }
    });
  }

  /**
   * Wait for a response frame with a specific id.
   * Useful when you've already sent the request manually.
   * @param {string} id - Request id to await
   * @param {number} [timeoutMs]
   * @returns {Promise<object>}
   */
  waitForResponse(id, timeoutMs = DEFAULT_TIMEOUT_MS) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this._pending.delete(id);
        reject(new Error(`GatewayRpc: timeout waiting for response id=${id}`));
      }, timeoutMs);

      this._pending.set(id, { resolve, reject, timer });
    });
  }

  // ─── private ────────────────────────────────────────────────────────────────

  _handleMessage(frame) {
    if (frame.type !== 'res' || !frame.id) return;

    const pending = this._pending.get(frame.id);
    if (!pending) return;

    clearTimeout(pending.timer);
    this._pending.delete(frame.id);

    if (frame.ok === false) {
      pending.reject(
        new Error(`GatewayRpc: server returned error for id=${frame.id}: ${JSON.stringify(frame.payload)}`)
      );
    } else {
      pending.resolve(frame.payload);
    }
  }
}

module.exports = GatewayRpc;
