const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dbPath = process.env.DB_PATH || './data/niuma.db';
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

const db = new sqlite3.Database(dbPath);

function runAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
}

function getAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function allAsync(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

async function initSchema() {
  const schema = `
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS agents (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      role_type TEXT NOT NULL,
      bio TEXT,
      avatar_url TEXT,
      system_prompt TEXT,
      created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      owner_id TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS project_members (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL,
      agent_id TEXT NOT NULL,
      nickname TEXT,
      duties TEXT,
      level TEXT NOT NULL DEFAULT 'member',
      joined_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS chats (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      project_id TEXT,
      user_id TEXT NOT NULL,
      title TEXT,
      created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS chat_agents (
      chat_id TEXT NOT NULL,
      agent_id TEXT NOT NULL,
      PRIMARY KEY (chat_id, agent_id)
    );
    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      chat_id TEXT NOT NULL,
      sender_type TEXT NOT NULL,
      sender_id TEXT NOT NULL,
      content TEXT NOT NULL DEFAULT '',
      thinking TEXT,
      status TEXT NOT NULL DEFAULT 'done',
      created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS otps (
      email TEXT PRIMARY KEY,
      code TEXT NOT NULL,
      expires_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS knowledge_docs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id TEXT NOT NULL,
      title TEXT NOT NULL,
      content TEXT NOT NULL DEFAULT '',
      author_type TEXT NOT NULL DEFAULT 'user',
      author_id TEXT,
      author_name TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS tasks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'todo',
      priority TEXT NOT NULL DEFAULT 'normal',
      created_by_type TEXT NOT NULL DEFAULT 'user',
      created_by TEXT,
      assigned_to TEXT,
      due_at INTEGER,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
    );
  `;
  for (const stmt of schema.split(';').map(s => s.trim()).filter(Boolean)) {
    await runAsync(stmt);
  }
  // Idempotent migrations
  db.run(`ALTER TABLE messages ADD COLUMN type TEXT DEFAULT 'text'`, () => {});
  db.run(`ALTER TABLE messages ADD COLUMN file_url TEXT`, () => {});
  db.run(`ALTER TABLE messages ADD COLUMN file_name TEXT`, () => {});
  db.run(`ALTER TABLE messages ADD COLUMN file_size INTEGER`, () => {});
  db.run(`ALTER TABLE messages ADD COLUMN duration REAL`, () => {});  // audio duration in seconds
  db.run(`ALTER TABLE agents ADD COLUMN thinking_level TEXT DEFAULT 'low'`, () => {});  // off|minimal|low|medium|high
  db.run(`ALTER TABLE agents ADD COLUMN model_override TEXT`, () => {});  // e.g. github-copilot/claude-opus-4.6

  // peer_reviews: 存储互评打分记录，用于 Agent 学习反馈
  db.run(`CREATE TABLE IF NOT EXISTS peer_reviews (
    id TEXT PRIMARY KEY,
    chat_id TEXT NOT NULL,
    msg_id TEXT NOT NULL,
    author_id TEXT NOT NULL,
    reviewer_id TEXT NOT NULL,
    review_text TEXT NOT NULL,
    score INTEGER,            -- 解析出的综合评分 1-5（可选）
    created_at INTEGER NOT NULL
  )`, () => {});
}

module.exports = { db, runAsync, getAsync, allAsync, initSchema };

