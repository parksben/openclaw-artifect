// SSE event bus — in-process pub/sub for chat streams
const EventEmitter = require('events');
const bus = new EventEmitter();
bus.setMaxListeners(200);

function emit(chatId, event) {
  bus.emit(`chat:${chatId}`, event);
}

function subscribe(chatId, handler) {
  bus.on(`chat:${chatId}`, handler);
}

function unsubscribe(chatId, handler) {
  bus.off(`chat:${chatId}`, handler);
}

module.exports = { emit, subscribe, unsubscribe };
