const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getAsync, runAsync, allAsync } = require('../db');
const { sign, authMiddleware } = require('../auth');
const { sendOtp, sendMail } = require('../smtp');

// In-memory code store for email OTP (new endpoints)
// email → { code, expiresAt }
const code_store = new Map();

// POST /api/auth/send-code — new email OTP endpoint (in-memory, 5 min TTL)
router.post('/send-code', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });

  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = Date.now() + 5 * 60 * 1000; // 5 minutes
  code_store.set(email, { code, expiresAt });

  try {
    await sendMail({
      to: email,
      subject: '牛马登录验证码',
      text: `您的验证码是：${code}\n\n5分钟内有效，请勿泄露。`,
      html: `<p>您的验证码是：<strong style="font-size:24px;letter-spacing:4px">${code}</strong></p><p>5分钟内有效，请勿泄露。</p>`,
    });
  } catch (err) {
    console.error('[smtp] Failed to send code:', err.message);
    if (process.env.NODE_ENV !== 'production') {
      return res.json({ ok: true, _dev_code: code });
    }
    return res.status(500).json({ error: 'Failed to send email' });
  }

  res.json({ ok: true });
});

// POST /api/auth/verify-code — verify email OTP and return JWT
router.post('/verify-code', async (req, res) => {
  const { email, code } = req.body;
  if (!email || !code) return res.status(400).json({ error: 'email and code required' });

  const entry = code_store.get(email);
  if (!entry) return res.status(400).json({ error: 'No code found for this email' });
  if (entry.code !== String(code)) return res.status(400).json({ error: 'Invalid code' });
  if (Date.now() > entry.expiresAt) {
    code_store.delete(email);
    return res.status(400).json({ error: 'Code expired' });
  }
  code_store.delete(email);

  // Upsert user
  let user = await getAsync('SELECT * FROM users WHERE email = ?', [email]);
  if (!user) {
    const id = uuidv4();
    const now = Date.now();
    await runAsync('INSERT INTO users (id, email, created_at) VALUES (?, ?, ?)', [id, email, now]);
    user = { id, email, created_at: now };

    // Auto-create 1v1 chats with all agents
    const agents = await allAsync('SELECT id, name FROM agents', []);
    for (const agent of agents) {
      const chatId = uuidv4();
      await runAsync(
        'INSERT INTO chats (id, type, project_id, user_id, title, created_at) VALUES (?, ?, NULL, ?, ?, ?)',
        [chatId, 'direct', id, agent.name, now]
      );
      await runAsync('INSERT INTO chat_agents (chat_id, agent_id) VALUES (?, ?)', [chatId, agent.id]);
    }
  }

  const token = sign({ id: user.id, email: user.email });
  res.json({ ok: true, token, user });
});

// POST /auth/send-otp  (legacy)
// POST /api/auth/otp/send  (App client)
router.post(['/send-otp', '/otp/send'], async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: 'email required' });

  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = Date.now() + 10 * 60 * 1000; // 10 minutes

  await runAsync(
    'INSERT OR REPLACE INTO otps (email, code, expires_at) VALUES (?, ?, ?)',
    [email, code, expiresAt]
  );

  try {
    await sendOtp(email, code);
  } catch (err) {
    console.error('[smtp] Failed to send OTP:', err.message);
    // In dev mode, return code in response for testing
    if (process.env.NODE_ENV !== 'production') {
      return res.json({ message: 'OTP sent (dev mode)', _dev_code: code });
    }
    return res.status(500).json({ error: 'Failed to send email' });
  }

  res.json({ message: 'OTP sent' });
});

// POST /auth/verify-otp  (legacy)
// POST /api/auth/otp/verify  (App client)
router.post(['/verify-otp', '/otp/verify'], async (req, res) => {
  const { email, code } = req.body;
  if (!email || !code) return res.status(400).json({ error: 'email and code required' });

  const otp = await getAsync('SELECT * FROM otps WHERE email = ?', [email]);
  if (!otp) return res.status(400).json({ error: 'No OTP found for this email' });
  if (otp.code !== code) return res.status(400).json({ error: 'Invalid code' });
  if (Date.now() > otp.expires_at) return res.status(400).json({ error: 'OTP expired' });

  // Delete used OTP
  await runAsync('DELETE FROM otps WHERE email = ?', [email]);

  // Upsert user
  let user = await getAsync('SELECT * FROM users WHERE email = ?', [email]);
  if (!user) {
    const id = uuidv4();
    const now = Date.now();
    await runAsync('INSERT INTO users (id, email, created_at) VALUES (?, ?, ?)', [id, email, now]);
    user = { id, email, created_at: now };

    // Auto-create 1v1 chats with all agents
    const agents = await allAsync('SELECT id, name FROM agents', []);
    for (const agent of agents) {
      const chatId = uuidv4();
      await runAsync(
        'INSERT INTO chats (id, type, project_id, user_id, title, created_at) VALUES (?, ?, NULL, ?, ?, ?)',
        [chatId, 'direct', id, agent.name, now]
      );
      await runAsync('INSERT INTO chat_agents (chat_id, agent_id) VALUES (?, ?)', [chatId, agent.id]);
    }
  }

  const token = sign({ id: user.id, email: user.email });
  res.json({ token, user });
});

// GET /api/auth/me — 验证 token 并返回当前用户
router.get('/me', authMiddleware, async (req, res) => {
  const user = await getAsync('SELECT id, email, created_at FROM users WHERE id = ?', [req.user.id]);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(user);
});

module.exports = router;
