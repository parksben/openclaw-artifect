const express = require('express');
const router = express.Router();
const { templates, getTemplate } = require('../skills');

// GET /api/templates — 返回所有模板列表（前端展示用）
router.get('/', (req, res) => {
  // 返回精简字段列表，避免 systemPrompt 过长影响列表性能
  const list = templates.map(({ id, name, emoji, description, color, skills, tools, personality }) => ({
    id,
    name,
    emoji,
    description,
    color,
    skills,
    tools,
    personality,
  }));
  res.json({ ok: true, data: list });
});

// GET /api/templates/:id — 返回单个模板详情（含 systemPrompt、cronSchedules 等）
router.get('/:id', (req, res) => {
  const template = getTemplate(req.params.id);
  if (!template) {
    return res.status(404).json({ ok: false, error: `Template "${req.params.id}" not found` });
  }
  res.json({ ok: true, data: template });
});

module.exports = router;
