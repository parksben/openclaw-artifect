const express = require('express');
const router = express.Router();
const { allAsync } = require('../db');
const { authMiddleware } = require('../auth');

// GET /api/overview
router.get('/', authMiddleware, async (req, res) => {
  try {
    // Agents by role
    const agentRows = await allAsync(
      `SELECT role_type, COUNT(*) as count, GROUP_CONCAT(name) as names FROM agents GROUP BY role_type`,
      []
    );
    const totalAgents = agentRows.reduce((sum, r) => sum + r.count, 0);
    const byRole = agentRows.map(r => ({
      role_type: r.role_type,
      count: r.count,
      names: r.names ? r.names.split(',') : [],
    }));

    // All projects
    const projects = await allAsync('SELECT id, name FROM projects ORDER BY created_at ASC', []);

    // Tasks per project
    const taskRows = await allAsync(
      `SELECT project_id,
        COUNT(*) as total,
        SUM(CASE WHEN status='todo' THEN 1 ELSE 0 END) as todo,
        SUM(CASE WHEN status='doing' THEN 1 ELSE 0 END) as doing,
        SUM(CASE WHEN status='review' THEN 1 ELSE 0 END) as review,
        SUM(CASE WHEN status='done' THEN 1 ELSE 0 END) as done,
        SUM(CASE WHEN status='blocked' THEN 1 ELSE 0 END) as blocked
       FROM tasks GROUP BY project_id`,
      []
    );
    const taskMap = {};
    taskRows.forEach(r => { taskMap[r.project_id] = r; });

    // Docs per project
    const docRows = await allAsync(
      `SELECT project_id, COUNT(*) as count FROM knowledge_docs GROUP BY project_id`,
      []
    );
    const docMap = {};
    docRows.forEach(r => { docMap[r.project_id] = r.count; });

    // Members per project
    const memberRows = await allAsync(
      `SELECT project_id, COUNT(*) as count FROM project_members GROUP BY project_id`,
      []
    );
    const memberMap = {};
    memberRows.forEach(r => { memberMap[r.project_id] = r.count; });

    // Assemble project overviews
    let totalTasks = 0;
    let totalDone = 0;
    let totalDocs = 0;

    const projectOverviews = projects.map(p => {
      const t = taskMap[p.id] || { total: 0, todo: 0, doing: 0, review: 0, done: 0, blocked: 0 };
      const total = Number(t.total);
      const done = Number(t.done);
      const doneRate = total > 0 ? Math.round((done / total) * 100) : 0;
      const docCount = Number(docMap[p.id] || 0);
      totalTasks += total;
      totalDone += done;
      totalDocs += docCount;
      return {
        id: p.id,
        name: p.name,
        memberCount: Number(memberMap[p.id] || 0),
        tasks: {
          total,
          todo: Number(t.todo),
          doing: Number(t.doing),
          review: Number(t.review),
          done,
          blocked: Number(t.blocked),
          doneRate,
        },
        docCount,
      };
    });

    const overallDoneRate = totalTasks > 0 ? Math.round((totalDone / totalTasks) * 100) : 0;

    res.json({
      agents: { total: totalAgents, byRole },
      projects: projectOverviews,
      summary: {
        totalProjects: projects.length,
        totalTasks,
        totalDone,
        totalDocs,
        overallDoneRate,
      },
    });
  } catch (err) {
    console.error('[overview]', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
