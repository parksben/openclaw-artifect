const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getAsync, runAsync, allAsync } = require('../db');
const { authMiddleware } = require('../auth');
const { saveMessage } = require('../services/agentRunner');
const { runPlannerExecutor } = require('../services/planner');
const events = require('../events');

// GET /chats
router.get('/', authMiddleware, async (req, res) => {
  const chats = await allAsync(
    'SELECT * FROM chats WHERE user_id = ? ORDER BY created_at DESC',
    [req.user.id]
  );
  res.json(chats);
});

// POST /chats  or  POST /chats/group  (create group chat)
router.post(['/', '/group'], authMiddleware, async (req, res) => {
  const { project_id, title, agent_ids } = req.body;
  if (!project_id) return res.status(400).json({ error: 'project_id required' });
  if (!Array.isArray(agent_ids) || agent_ids.length === 0) {
    return res.status(400).json({ error: 'agent_ids required' });
  }

  const project = await getAsync('SELECT * FROM projects WHERE id = ? AND owner_id = ?', [project_id, req.user.id]);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const id = uuidv4();
  const now = Date.now();
  await runAsync(
    'INSERT INTO chats (id, type, project_id, user_id, title, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    [id, 'group', project_id, req.user.id, title || project.name, now]
  );

  for (const agentId of agent_ids) {
    await runAsync('INSERT OR IGNORE INTO chat_agents (chat_id, agent_id) VALUES (?, ?)', [id, agentId]);
  }

  res.status(201).json({ id, type: 'group', project_id, user_id: req.user.id, title: title || project.name, created_at: now, agent_ids });
});

// GET /chats/:id/messages
router.get('/:id/messages', authMiddleware, async (req, res) => {
  const chat = await getAsync('SELECT * FROM chats WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
  if (!chat) return res.status(404).json({ error: 'Chat not found' });

  const limit = parseInt(req.query.limit) || 50;
  const before = req.query.before; // cursor-based pagination

  let sql = 'SELECT * FROM messages WHERE chat_id = ?';
  const params = [req.params.id];
  if (before) {
    const pivot = await getAsync('SELECT created_at FROM messages WHERE id = ?', [before]);
    if (pivot) {
      sql += ' AND created_at < ?';
      params.push(pivot.created_at);
    }
  }
  sql += ' ORDER BY created_at DESC LIMIT ?';
  params.push(limit);

  const messages = await allAsync(sql, params);
  res.json(messages.reverse());
});

// POST /chats/:id/messages  (send message, trigger agent replies)
// Supports: { content, type, file_url, file_name, file_size, duration }
// type: 'text' | 'audio' | 'image' | 'file'
router.post('/:id/messages', authMiddleware, async (req, res) => {
  const chat = await getAsync('SELECT * FROM chats WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
  if (!chat) return res.status(404).json({ error: 'Chat not found' });

  const { content = '', type = 'text', file_url, file_name, file_size, duration } = req.body;

  // text 消息必须有内容；audio/image/file 必须有 file_url
  if (type === 'text' && !content.trim()) return res.status(400).json({ error: 'content required' });
  if (type !== 'text' && !file_url) return res.status(400).json({ error: 'file_url required' });

  // Save user message
  const userMsg = await saveMessage({
    chatId: req.params.id,
    senderType: 'user',
    senderId: req.user.id,
    content: content || '',
    type,
    file_url,
    file_name,
    file_size,
    duration,
  });

  // Get agents in this chat
  const agentRows = await allAsync('SELECT agent_id FROM chat_agents WHERE chat_id = ?', [req.params.id]);
  const agentIds = agentRows.map(r => r.agent_id);

  // Load recent history
  const history = await allAsync(
    'SELECT * FROM messages WHERE chat_id = ? ORDER BY created_at DESC LIMIT 20',
    [req.params.id]
  );
  history.reverse();

  // Respond immediately; agent replies happen async
  res.status(201).json(userMsg);

  // Trigger agent replies (non-blocking)
  if (agentIds.length > 0) {
    setImmediate(async () => {
      try {
        // Build knowledge base context if project has docs
        let kbContext = '';
        if (chat.project_id) {
          const docs = await allAsync(
            'SELECT id, title, author_name, updated_at FROM knowledge_docs WHERE project_id = ?',
            [chat.project_id]
          );
          if (docs.length > 0) {
            const docSummary = docs.map(d => `- [${d.title}] by ${d.author_name || '用户'}, 更新于 ${d.updated_at}`).join('\n');
            kbContext = `\n\n## 项目知识库\n${docSummary}\n\n如需查看文档全文，请在回复中使用：[[read_doc:${docs[0].id}]] 格式引用文档ID。`;
          }
          // Build task context for each agent
          for (const agentId of agentIds) {
            const agentTasks = await allAsync(
              "SELECT title, status, priority FROM tasks WHERE project_id = ? AND assigned_to = ? AND status IN ('todo', 'doing', 'review', 'blocked') ORDER BY created_at DESC LIMIT 20",
              [chat.project_id, agentId]
            );
            if (agentTasks.length > 0) {
              const taskSummary = agentTasks.map(t => `- [${t.priority.toUpperCase()}] ${t.title}（status: ${t.status}）`).join('\n');
              kbContext += `\n\n## 我的待办任务\n${taskSummary}`;
            }
          }
        }
        await runPlannerExecutor({ chatId: req.params.id, agentIds, history, userMessage: content, kbContext });
      } catch (err) {
        console.error('[planner] Error:', err.message);
      }
    });
  }
});

// GET /chats/:id/stream  (SSE)
router.get('/:id/stream', authMiddleware, (req, res) => {
  const chatId = req.params.id;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  // Send keep-alive every 30s
  const keepAlive = setInterval(() => {
    res.write(': ping\n\n');
  }, 30000);

  const handler = (event) => {
    res.write(`event: ${event.type}\n`);
    res.write(`data: ${JSON.stringify(event.data)}\n\n`);
  };

  events.subscribe(chatId, handler);

  req.on('close', () => {
    clearInterval(keepAlive);
    events.unsubscribe(chatId, handler);
  });
});

// POST /chats/:id/messages/:msgId/transcribe
// 长按音频消息 → 通过 OpenClaw 转写文字
router.post('/:id/messages/:msgId/transcribe', authMiddleware, async (req, res) => {
  const chat = await getAsync('SELECT * FROM chats WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
  if (!chat) return res.status(404).json({ error: 'Chat not found' });

  const msg = await getAsync('SELECT * FROM messages WHERE id = ? AND chat_id = ?', [req.params.msgId, req.params.id]);
  if (!msg) return res.status(404).json({ error: 'Message not found' });
  if (msg.type !== 'audio') return res.status(400).json({ error: 'Not an audio message' });
  if (!msg.file_url) return res.status(400).json({ error: 'No audio file' });

  try {
    // 通过 openclaw agent 调模型转写
    // 把音频文件路径传给 agent，让模型直接理解音频内容
    const uploadBase = process.env.UPLOAD_DIR || require('path').join(process.env.HOME, '.niuma', 'uploads');
    // file_url 形如 /uploads/audio/xxx.webm，转为本地绝对路径
    const localPath = require('path').join(uploadBase, '..', msg.file_url.replace(/^\/uploads\//, ''));
    const { execSync } = require('child_process');
    const prompt = `请转写以下音频文件的内容，只输出转写文字，不要加任何说明。文件路径：${localPath}`;
    const result = execSync(
      `openclaw agent --agent main --message ${JSON.stringify(prompt)} --json`,
      { timeout: 30000, encoding: 'utf8' }
    );
    const parsed = JSON.parse(result);
    const text = (parsed?.result?.payloads || []).map(p => p.text || '').join('').trim();
    res.json({ text });
  } catch (err) {
    console.error('[transcribe] Error:', err.message);
    res.status(500).json({ error: 'Transcription failed', detail: err.message });
  }
});

module.exports = router;


