const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getAsync, runAsync, allAsync } = require('../db');
const { authMiddleware } = require('../auth');

// GET /projects
router.get('/', authMiddleware, async (req, res) => {
  const projects = await allAsync(
    'SELECT * FROM projects WHERE owner_id = ? ORDER BY created_at DESC',
    [req.user.id]
  );
  res.json(projects);
});

// POST /projects
router.post('/', authMiddleware, async (req, res) => {
  const { name, description } = req.body;
  if (!name) return res.status(400).json({ error: 'name required' });
  const id = uuidv4();
  const now = Date.now();
  await runAsync(
    'INSERT INTO projects (id, name, description, owner_id, created_at) VALUES (?, ?, ?, ?, ?)',
    [id, name, description || null, req.user.id, now]
  );
  res.status(201).json({ id, name, description, owner_id: req.user.id, created_at: now });
});

// GET /projects/:id
router.get('/:id', authMiddleware, async (req, res) => {
  const project = await getAsync('SELECT * FROM projects WHERE id = ? AND owner_id = ?', [req.params.id, req.user.id]);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const members = await allAsync(
    `SELECT pm.*, a.name as agent_name, a.role_type, a.bio, a.avatar_url
     FROM project_members pm
     JOIN agents a ON pm.agent_id = a.id
     WHERE pm.project_id = ?`,
    [req.params.id]
  );

  res.json({ ...project, members });
});

// POST /projects/:id/members
router.post('/:id/members', authMiddleware, async (req, res) => {
  const project = await getAsync('SELECT * FROM projects WHERE id = ? AND owner_id = ?', [req.params.id, req.user.id]);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const { agent_id, nickname, duties, level } = req.body;
  if (!agent_id) return res.status(400).json({ error: 'agent_id required' });

  const agent = await getAsync('SELECT id FROM agents WHERE id = ?', [agent_id]);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });

  const id = uuidv4();
  const now = Date.now();
  await runAsync(
    'INSERT INTO project_members (id, project_id, agent_id, nickname, duties, level, joined_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [id, req.params.id, agent_id, nickname || null, duties || null, level || 'member', now]
  );

  res.status(201).json({ id, project_id: req.params.id, agent_id, nickname, duties, level: level || 'member', joined_at: now });
});

// PATCH /projects/:id/members/:memberId
router.patch('/:id/members/:memberId', authMiddleware, async (req, res) => {
  const project = await getAsync('SELECT * FROM projects WHERE id = ? AND owner_id = ?', [req.params.id, req.user.id]);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  const member = await getAsync('SELECT * FROM project_members WHERE id = ? AND project_id = ?', [req.params.memberId, req.params.id]);
  if (!member) return res.status(404).json({ error: 'Member not found' });

  const { nickname, duties, level } = req.body;
  const updates = {};
  if (nickname !== undefined) updates.nickname = nickname;
  if (duties !== undefined) updates.duties = duties;
  if (level !== undefined) updates.level = level;

  if (Object.keys(updates).length === 0) return res.json(member);

  const setClauses = Object.keys(updates).map(k => `${k} = ?`).join(', ');
  await runAsync(
    `UPDATE project_members SET ${setClauses} WHERE id = ?`,
    [...Object.values(updates), req.params.memberId]
  );

  res.json({ ...member, ...updates });
});

// DELETE /projects/:id/members/:memberId
router.delete('/:id/members/:memberId', authMiddleware, async (req, res) => {
  const project = await getAsync('SELECT * FROM projects WHERE id = ? AND owner_id = ?', [req.params.id, req.user.id]);
  if (!project) return res.status(404).json({ error: 'Project not found' });

  await runAsync('DELETE FROM project_members WHERE id = ? AND project_id = ?', [req.params.memberId, req.params.id]);
  res.json({ message: 'Member removed' });
});

module.exports = router;
