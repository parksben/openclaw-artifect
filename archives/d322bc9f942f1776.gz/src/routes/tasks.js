const express = require('express');
const router = express.Router({ mergeParams: true });
const { getAsync, runAsync, allAsync } = require('../db');
const { authMiddleware } = require('../auth');

const VALID_STATUS = ['todo', 'doing', 'review', 'done', 'blocked'];
const VALID_PRIORITY = ['low', 'normal', 'high', 'urgent'];

// GET /projects/:id/tasks
router.get('/', authMiddleware, async (req, res) => {
  try {
    const project = await getAsync('SELECT * FROM projects WHERE id = ?', [req.params.id]);
    if (!project) return res.status(404).json({ error: 'Project not found' });

    const { status, assigned_to, priority } = req.query;
    let sql = 'SELECT * FROM tasks WHERE project_id = ?';
    const params = [req.params.id];
    if (status) { sql += ' AND status = ?'; params.push(status); }
    if (assigned_to) { sql += ' AND assigned_to = ?'; params.push(assigned_to); }
    if (priority) { sql += ' AND priority = ?'; params.push(priority); }
    sql += ' ORDER BY created_at DESC';

    const tasks = await allAsync(sql, params);
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /projects/:id/tasks
router.post('/', authMiddleware, async (req, res) => {
  try {
    const project = await getAsync('SELECT * FROM projects WHERE id = ?', [req.params.id]);
    if (!project) return res.status(404).json({ error: 'Project not found' });

    const { title, description = '', priority = 'normal', assigned_to, due_at } = req.body;
    if (!title) return res.status(400).json({ error: 'title required' });
    if (priority && !VALID_PRIORITY.includes(priority)) return res.status(400).json({ error: 'invalid priority' });

    const now = Date.now();
    const result = await runAsync(
      'INSERT INTO tasks (project_id, title, description, status, priority, created_by_type, created_by, assigned_to, due_at, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [req.params.id, title, description, 'todo', priority, 'user', req.user.id, assigned_to || null, due_at || null, now, now]
    );

    const task = await getAsync('SELECT * FROM tasks WHERE id = ?', [result.lastID]);
    res.status(201).json(task);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /projects/:id/tasks/:taskId
router.get('/:taskId', authMiddleware, async (req, res) => {
  try {
    const task = await getAsync('SELECT * FROM tasks WHERE id = ? AND project_id = ?', [req.params.taskId, req.params.id]);
    if (!task) return res.status(404).json({ error: 'Task not found' });
    res.json(task);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /projects/:id/tasks/:taskId
router.put('/:taskId', authMiddleware, async (req, res) => {
  try {
    const task = await getAsync('SELECT * FROM tasks WHERE id = ? AND project_id = ?', [req.params.taskId, req.params.id]);
    if (!task) return res.status(404).json({ error: 'Task not found' });

    const { title, description, status, priority, assigned_to, due_at } = req.body;
    if (status && !VALID_STATUS.includes(status)) return res.status(400).json({ error: 'invalid status' });
    if (priority && !VALID_PRIORITY.includes(priority)) return res.status(400).json({ error: 'invalid priority' });

    const newTitle = title !== undefined ? title : task.title;
    const newDesc = description !== undefined ? description : task.description;
    const newStatus = status !== undefined ? status : task.status;
    const newPriority = priority !== undefined ? priority : task.priority;
    const newAssigned = assigned_to !== undefined ? assigned_to : task.assigned_to;
    const newDueAt = due_at !== undefined ? due_at : task.due_at;
    const now = Date.now();

    await runAsync(
      'UPDATE tasks SET title=?, description=?, status=?, priority=?, assigned_to=?, due_at=?, updated_at=? WHERE id=?',
      [newTitle, newDesc, newStatus, newPriority, newAssigned, newDueAt, now, req.params.taskId]
    );

    const updated = await getAsync('SELECT * FROM tasks WHERE id = ?', [req.params.taskId]);
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /projects/:id/tasks/:taskId
router.delete('/:taskId', authMiddleware, async (req, res) => {
  try {
    const task = await getAsync('SELECT * FROM tasks WHERE id = ? AND project_id = ?', [req.params.taskId, req.params.id]);
    if (!task) return res.status(404).json({ error: 'Task not found' });
    await runAsync('DELETE FROM tasks WHERE id = ?', [req.params.taskId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
