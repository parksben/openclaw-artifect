const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { execSync } = require('child_process');
const path = require('path');

// Role template model + thinking defaults
const ROLE_DEFAULTS = {
  'pm':              { model: 'github-copilot/claude-sonnet-4.6', thinking: 'low' },
  'project-manager': { model: 'github-copilot/claude-haiku-4.5',  thinking: 'off' },
  'frontend-dev':    { model: 'github-copilot/claude-opus-4.6',   thinking: 'low' },
  'backend-dev':     { model: 'github-copilot/claude-opus-4.6',   thinking: 'low' },
  'designer':        { model: 'github-copilot/claude-haiku-4.5',  thinking: 'off' },
  'data-analyst':    { model: 'github-copilot/claude-sonnet-4.6', thinking: 'medium' },
  'qa-engineer':     { model: 'github-copilot/claude-haiku-4.5',  thinking: 'off' },
};
const fs = require('fs');
const { getAsync, allAsync, runAsync } = require('../db');
const { authMiddleware } = require('../auth');

// ─── helpers ───────────────────────────────────────────────────────────────

function nanoid6() {
  return Math.random().toString(36).substring(2, 8);
}

function buildSystemPrompt({ name, roleType, bio, duties, style, verbosity, emoji }) {
  const styleMap = {
    professional: '沟通风格专业严谨，用词精准，保持职业态度',
    friendly: '沟通风格活泼友好，适当使用 emoji，让团队氛围轻松',
    concise: '沟通风格简洁直接，结论先行，不废话',
  };
  const verbosityMap = {
    detailed: '汇报时提供详细说明，包括背景、过程和结论',
    balanced: '汇报时提供适中详细度，重点突出',
    brief: '汇报时极度简洁，每次回复控制在 100 字以内',
  };

  const WORK_RULES = `## 工作规范
1. 接单即响应：分配到的任务在下次扫描时必须立即开始，不拖延。
2. 先读文档：执行任务前必须先查看项目知识库，基于最新文档开展工作。
3. 产出即文档：完成阶段性工作后，主动在知识库中创建或更新对应文档。
4. 协作优先：工作中发现阻塞，立即在任务状态中标注 blocked 并说明原因。
5. 自驱自结：不等用户催促，主动扫描待办任务、主动执行、主动更新状态、主动汇报结果。
6. 简洁汇报：向用户汇报时，结论先行，控制在 200 字以内，详细内容写进知识库文档。`;

  return `你是 ${emoji} ${name}，${bio}

## 核心职责
${duties}

## 行为风格
- ${styleMap[style] || styleMap.balanced}
- ${verbosityMap[verbosity] || verbosityMap.balanced}

${WORK_RULES}`;
}

function createOpenClawAgent({ agentId, name, systemPrompt, modelOverride }) {
  const openclawHome = process.env.OPENCLAW_PATH || '/root/.openclaw';
  const wsDir = path.join(openclawHome, 'workspaces', agentId);
  fs.mkdirSync(wsDir, { recursive: true });
  fs.writeFileSync(path.join(wsDir, 'SOUL.md'), systemPrompt, 'utf8');
  fs.writeFileSync(path.join(wsDir, 'IDENTITY.md'),
    `# IDENTITY.md\n- **Name:** ${name}\n`, 'utf8');

  try {
    const modelFlag = modelOverride ? ` --model "${modelOverride}"` : '';
    execSync(
      `openclaw agents add "${agentId}" --workspace "${wsDir}"${modelFlag} --non-interactive`,
      { stdio: 'pipe', timeout: 15000 }
    );
    return { success: true };
  } catch (err) {
    const msg = err.message || '';
    const stderr = err.stderr?.toString() || '';
    if (msg.includes('already exists') || stderr.includes('already')) {
      return { success: true, existed: true };
    }
    throw new Error(`OpenClaw agent creation failed: ${msg}`);
  }
}

// ─── routes ────────────────────────────────────────────────────────────────

// GET /agents
router.get('/', authMiddleware, async (req, res) => {
  const agents = await allAsync('SELECT * FROM agents ORDER BY created_at ASC', []);
  res.json(agents);
});

// GET /agents/:id  (includes projects they're in)
router.get('/:id', authMiddleware, async (req, res) => {
  const agent = await getAsync('SELECT * FROM agents WHERE id = ?', [req.params.id]);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });

  const projects = await allAsync(
    `SELECT p.*, pm.nickname, pm.duties, pm.level, pm.joined_at
     FROM project_members pm
     JOIN projects p ON pm.project_id = p.id
     WHERE pm.agent_id = ?`,
    [req.params.id]
  );

  res.json({ ...agent, projects });
});

// POST /agents — create a custom agent
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { name, roleType, bio, duties, style, verbosity, emoji } = req.body;

    if (!name || !roleType || !bio || !duties || !style || !verbosity || !emoji) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const agentId = `niuma-${roleType}-${nanoid6()}`;
    const systemPrompt = buildSystemPrompt({ name, roleType, bio, duties, style, verbosity, emoji });
    const now = Date.now();

    // Apply role defaults for model + thinking, allow explicit overrides
    const roleDefaults = ROLE_DEFAULTS[roleType] || { model: null, thinking: 'low' };
    const thinkingLevel = req.body.thinkingLevel || roleDefaults.thinking;
    const modelOverride = req.body.modelOverride || roleDefaults.model || null;

    await runAsync(
      `INSERT INTO agents (id, name, role_type, bio, avatar_url, system_prompt, thinking_level, model_override, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [agentId, name, roleType, bio, emoji, systemPrompt, thinkingLevel, modelOverride, now]
    );

    // best-effort OpenClaw agent creation
    let openclawResult = null;
    try {
      openclawResult = createOpenClawAgent({ agentId, name, systemPrompt, modelOverride });
    } catch (e) {
      console.warn('[agents] OpenClaw create failed (non-fatal):', e.message);
    }

    const agent = await getAsync('SELECT * FROM agents WHERE id = ?', [agentId]);
    res.status(201).json({ ...agent, _openclaw: openclawResult });
  } catch (err) {
    console.error('[POST /agents]', err);
    res.status(500).json({ error: err.message });
  }
});

// DELETE /agents/:id
router.delete('/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const agent = await getAsync('SELECT * FROM agents WHERE id = ?', [id]);
    if (!agent) return res.status(404).json({ error: 'Agent not found' });

    await runAsync('DELETE FROM agents WHERE id = ?', [id]);

    // best-effort OpenClaw removal
    try {
      execSync(`openclaw agents rm "${id}"`, { stdio: 'pipe', timeout: 10000 });
    } catch (_) { /* non-fatal */ }

    res.json({ ok: true });
  } catch (err) {
    console.error('[DELETE /agents/:id]', err);
    res.status(500).json({ error: err.message });
  }
});

// GET /agents/:id/reviews — 获取某 Agent 的历史评分记录及均分
router.get('/:id/reviews', authMiddleware, async (req, res) => {
  try {
    const reviews = await allAsync(
      `SELECT reviewer_id, review_text, score, created_at
       FROM peer_reviews WHERE author_id = ?
       ORDER BY created_at DESC LIMIT 50`,
      [req.params.id]
    );
    // 统计均分
    const scored = reviews.filter(r => r.score != null);
    const avgScore = scored.length ? (scored.reduce((s, r) => s + r.score, 0) / scored.length).toFixed(1) : null;
    res.json({ agentId: req.params.id, avgScore, total: reviews.length, reviews });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

