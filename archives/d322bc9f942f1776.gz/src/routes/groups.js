/**
 * groups.js — Route handlers for group (chat) lifecycle control.
 * Mounts as /api/groups
 */

'use strict';

const express = require('express');
const router = express.Router();
const { authMiddleware } = require('../auth');
const { getAsync } = require('../db');
const LifecycleService = require('../services/LifecycleService');
const AgentService = require('../services/AgentService');
const GatewayHttp = require('../gateway/GatewayHttp');

// Lazily instantiated services
let lifecycleService;
function getLifecycleService() {
  if (!lifecycleService) {
    const gatewayHttp = new GatewayHttp();
    const agentService = new AgentService(gatewayHttp);
    lifecycleService = new LifecycleService(agentService);
  }
  return lifecycleService;
}

/**
 * POST /api/groups/:id/control
 * Body: { action: "pause" | "resume" | "stop" }
 */
router.post('/:id/control', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { action } = req.body;

    if (!action || !['pause', 'resume', 'stop'].includes(action)) {
      return res.status(400).json({ error: 'action must be one of: pause, resume, stop' });
    }

    // Verify the group (chat) exists and the user has access
    const group = await getAsync('SELECT * FROM chats WHERE id = ?', [id]);
    if (!group) return res.status(404).json({ error: 'Group not found' });

    // Optional: check ownership (group.user_id === req.user.id)
    if (group.user_id && group.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const svc = getLifecycleService();
    const result = await svc.control(id, action);
    res.json(result);
  } catch (err) {
    console.error('[groups.control] error:', err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
