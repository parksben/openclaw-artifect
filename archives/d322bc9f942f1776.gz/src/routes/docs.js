const express = require('express');
const router = express.Router({ mergeParams: true });
const { getAsync, runAsync, allAsync } = require('../db');
const { authMiddleware } = require('../auth');

// GET /projects/:id/docs
router.get('/', authMiddleware, async (req, res) => {
  try {
    const project = await getAsync('SELECT * FROM projects WHERE id = ?', [req.params.id]);
    if (!project) return res.status(404).json({ error: 'Project not found' });

    const docs = await allAsync(
      'SELECT id, title, author_name, author_type, created_at, updated_at, substr(content, 1, 100) as preview FROM knowledge_docs WHERE project_id = ? ORDER BY updated_at DESC',
      [req.params.id]
    );
    res.json(docs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /projects/:id/docs
router.post('/', authMiddleware, async (req, res) => {
  try {
    const project = await getAsync('SELECT * FROM projects WHERE id = ?', [req.params.id]);
    if (!project) return res.status(404).json({ error: 'Project not found' });

    const { title, content = '' } = req.body;
    if (!title) return res.status(400).json({ error: 'title required' });

    const user = await getAsync('SELECT * FROM users WHERE id = ?', [req.user.id]);
    const authorName = user ? (user.email || req.user.id) : req.user.id;

    const result = await runAsync(
      'INSERT INTO knowledge_docs (project_id, title, content, author_type, author_id, author_name) VALUES (?, ?, ?, ?, ?, ?)',
      [req.params.id, title, content, 'user', req.user.id, authorName]
    );

    const doc = await getAsync('SELECT * FROM knowledge_docs WHERE id = ?', [result.lastID]);
    res.status(201).json(doc);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /projects/:id/docs/:docId
router.get('/:docId', authMiddleware, async (req, res) => {
  try {
    const doc = await getAsync(
      'SELECT * FROM knowledge_docs WHERE id = ? AND project_id = ?',
      [req.params.docId, req.params.id]
    );
    if (!doc) return res.status(404).json({ error: 'Doc not found' });
    res.json(doc);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /projects/:id/docs/:docId
router.put('/:docId', authMiddleware, async (req, res) => {
  try {
    const doc = await getAsync(
      'SELECT * FROM knowledge_docs WHERE id = ? AND project_id = ?',
      [req.params.docId, req.params.id]
    );
    if (!doc) return res.status(404).json({ error: 'Doc not found' });

    const { title, content } = req.body;
    const newTitle = title !== undefined ? title : doc.title;
    const newContent = content !== undefined ? content : doc.content;

    await runAsync(
      'UPDATE knowledge_docs SET title = ?, content = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [newTitle, newContent, req.params.docId]
    );

    const updated = await getAsync('SELECT * FROM knowledge_docs WHERE id = ?', [req.params.docId]);
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /projects/:id/docs/:docId
router.delete('/:docId', authMiddleware, async (req, res) => {
  try {
    const doc = await getAsync(
      'SELECT * FROM knowledge_docs WHERE id = ? AND project_id = ?',
      [req.params.docId, req.params.id]
    );
    if (!doc) return res.status(404).json({ error: 'Doc not found' });

    await runAsync('DELETE FROM knowledge_docs WHERE id = ?', [req.params.docId]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
