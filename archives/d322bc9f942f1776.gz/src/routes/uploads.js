const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { authMiddleware } = require('../auth');

const BASE_UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(process.env.HOME || '/root', '.niuma/uploads');

// 按类型分目录
function getUploadDir(mimetype) {
  if (mimetype.startsWith('audio/')) return path.join(BASE_UPLOAD_DIR, 'audio');
  if (mimetype.startsWith('image/')) return path.join(BASE_UPLOAD_DIR, 'images');
  return path.join(BASE_UPLOAD_DIR, 'files');
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = getUploadDir(file.mimetype);
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  },
});

const upload = multer({ storage, limits: { fileSize: 100 * 1024 * 1024 } }); // 100MB

// POST /api/upload
// Body: multipart/form-data, field "file"
// Optional header: X-Audio-Duration (seconds, for audio messages)
router.post('/upload', authMiddleware, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });

  const mimetype = req.file.mimetype;
  let category = 'file';
  if (mimetype.startsWith('audio/')) category = 'audio';
  else if (mimetype.startsWith('image/')) category = 'image';

  const urlPath = `/uploads/${category === 'audio' ? 'audio' : category === 'image' ? 'images' : 'files'}/${req.file.filename}`;

  const result = {
    url: urlPath,
    name: req.file.originalname,
    size: req.file.size,
    type: mimetype,
    category,
  };

  // 音频时长（客户端上传时附带）
  if (category === 'audio' && req.headers['x-audio-duration']) {
    result.duration = parseFloat(req.headers['x-audio-duration']);
  }

  res.json(result);
});

// DELETE /api/upload (optional: 删除文件，暂预留)
// router.delete('/upload/:filename', authMiddleware, ...)

module.exports = router;
