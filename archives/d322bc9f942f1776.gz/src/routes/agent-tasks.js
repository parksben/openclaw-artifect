const express = require('express');
const router = express.Router({ mergeParams: true });
const { allAsync } = require('../db');
const { authMiddleware } = require('../auth');

// GET /api/agents/:agentId/tasks
// Cross-project: returns all pending tasks assigned to an agent
router.get('/:agentId/tasks', authMiddleware, async (req, res) => {
  try {
    const tasks = await allAsync(
      "SELECT * FROM tasks WHERE assigned_to = ? AND status IN ('todo', 'doing', 'blocked') ORDER BY created_at DESC",
      [req.params.agentId]
    );
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
