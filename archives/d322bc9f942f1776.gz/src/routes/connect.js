const express = require('express');
const router = express.Router();
const QRCode = require('qrcode');
const { authMiddleware } = require('../auth');

// In-memory store for PC pairing codes
// code → { userId, token, serverUrl, expiresAt }
const pc_codes = new Map();

// Cleanup expired codes periodically
setInterval(() => {
  const now = Date.now();
  for (const [code, data] of pc_codes.entries()) {
    if (now > data.expiresAt) pc_codes.delete(code);
  }
}, 60 * 1000);

// GET /api/connect/qr-data
// Returns base64-encoded server connection payload
router.get('/qr-data', (req, res) => {
  const payload = {
    v: 1,
    type: 'niuma-connect',
    server: process.env.SERVER_URL || `http://localhost:${process.env.PORT || 3000}`,
    name: process.env.SERVER_NAME || '我的牛马服务器',
    ts: Date.now(),
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64');
  res.json({ payload: encoded });
});

// GET /connect
// Returns an HTML page with a large QR code for server connection
router.get('/', async (req, res) => {
  const payload = {
    v: 1,
    type: 'niuma-connect',
    server: process.env.SERVER_URL || `http://localhost:${process.env.PORT || 3000}`,
    name: process.env.SERVER_NAME || '我的牛马服务器',
    ts: Date.now(),
  };
  const encoded = Buffer.from(JSON.stringify(payload)).toString('base64');

  try {
    const svgString = await QRCode.toString(encoded, { type: 'svg', width: 300, margin: 2 });

    const html = `<!DOCTYPE html>
<html lang="zh">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>连接牛马服务器</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: #0f0f0f;
      color: #e5e5e5;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      gap: 24px;
    }
    h1 { font-size: 1.4rem; font-weight: 600; color: #fff; }
    .qr-wrap {
      background: #fff;
      border-radius: 16px;
      padding: 20px;
      box-shadow: 0 0 40px rgba(255,255,255,0.08);
    }
    .qr-wrap svg { display: block; width: 280px; height: 280px; }
    p { font-size: 0.95rem; color: #888; text-align: center; }
    .server-name { color: #ccc; font-weight: 500; }
  </style>
</head>
<body>
  <h1>用牛马 App 扫码连接</h1>
  <div class="qr-wrap">${svgString}</div>
  <p>服务器：<span class="server-name">${process.env.SERVER_NAME || '我的牛马服务器'}</span></p>
  <p>扫码后即可在 App 中添加此服务器</p>
</body>
</html>`;

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(html);
  } catch (err) {
    console.error('[connect] QR generation error:', err);
    res.status(500).json({ error: 'Failed to generate QR code' });
  }
});

// POST /api/connect/pc-code
// App calls this (authenticated) to generate a 6-digit pairing code for PC login
router.post('/pc-code', authMiddleware, (req, res) => {
  // Clean up existing codes for this user
  for (const [code, data] of pc_codes.entries()) {
    if (data.userId === req.user.id) pc_codes.delete(code);
  }

  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = Date.now() + 2 * 60 * 1000; // 2 minutes

  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  const serverUrl = process.env.SERVER_URL || `http://localhost:${process.env.PORT || 3000}`;

  pc_codes.set(code, { userId: req.user.id, token, serverUrl, expiresAt });

  res.json({ code, expiresAt });
});

// POST /api/connect/pc-verify
// PC calls this with the 6-digit code to get a token
router.post('/pc-verify', (req, res) => {
  const { code } = req.body;
  if (!code) return res.status(400).json({ error: 'code required' });

  const data = pc_codes.get(String(code));
  if (!data) return res.status(400).json({ error: 'Invalid code' });
  if (Date.now() > data.expiresAt) {
    pc_codes.delete(code);
    return res.status(400).json({ error: 'Code expired' });
  }

  pc_codes.delete(code);
  res.json({ ok: true, token: data.token, serverUrl: data.serverUrl });
});

module.exports = router;
